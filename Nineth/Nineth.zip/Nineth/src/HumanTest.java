import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;

public class HumanTest {
    @Test
    public void testHumanConstructorAndGetters() {
        Human human = new Human("Иванов", "Иван", "Иванович", 1990, Gender.MALE);

        assertEquals("Иванов", human.getSurname());
        assertEquals("Иван", human.getName());
        assertEquals("Иванович", human.getFather());
        assertEquals(1990, human.getYear());
        assertEquals(Gender.MALE, human.getGender());
    }

    @Test
    public void testHumanSetters() {
        Human human = new Human("Иванов", "Иван", "Иванович", 1990, Gender.MALE);

        human.setSurname("Петров");
        human.setName("Петр");
        human.setFather("Петрович");
        human.setYear(1985);
        human.setGender(Gender.FEMALE);

        assertEquals("Петров", human.getSurname());
        assertEquals("Петр", human.getName());
        assertEquals("Петрович", human.getFather());
        assertEquals(1985, human.getYear());
        assertEquals(Gender.FEMALE, human.getGender());
    }

    @Test
    public void testHumanSetYearValidation() {
        Human human = new Human("Иванов", "Иван", "Иванович", 1990, Gender.MALE);

        assertThrows(IllegalArgumentException.class, () -> human.setYear(0));
        assertThrows(IllegalArgumentException.class, () -> human.setYear(-1));
    }

    @Test
    public void testHumanEquality() {
        Human human1 = new Human("Иванов", "Иван", "Иванович", 1990, Gender.MALE);
        Human human2 = new Human("Иванов", "Иван", "Иванович", 1990, Gender.MALE);
        Human human3 = new Human("Петров", "Петр", "Петрович", 1985, Gender.FEMALE);

        assertEquals(human1, human2);
        assertNotEquals(human1, human3);
        assertEquals(human1.hashCode(), human2.hashCode());
    }

    @Test
    public void testStudentConstructorAndGetters() {
        Student student = new Student("Иванов", "Иван", "Иванович", 1990, Gender.MALE,
                "МГУ", "Физфак", "Физика");

        assertEquals("Иванов", student.getSurname());
        assertEquals("МГУ", student.getUniver());
        assertEquals("Физфак", student.getFaculty());
        assertEquals("Физика", student.getSpecial());
    }

    @Test
    public void testStudentSetters() {
        Student student = new Student("Иванов", "Иван", "Иванович", 1990, Gender.MALE,
                "МГУ", "Физфак", "Физика");

        student.setUniver("СПбГУ");
        student.setFaculty("Матмех");
        student.setSpecial("Математика");

        assertEquals("СПбГУ", student.getUniver());
        assertEquals("Матмех", student.getFaculty());
        assertEquals("Математика", student.getSpecial());
    }

    @Test
    public void testStudentEquality() {
        Student student1 = new Student("Иванов", "Иван", "Иванович", 1990, Gender.MALE,
                "МГУ", "Физфак", "Физика");
        Student student2 = new Student("Иванов", "Иван", "Иванович", 1990, Gender.MALE,
                "МГУ", "Физфак", "Физика");
        Student student3 = new Student("Петров", "Петр", "Петрович", 1991, Gender.FEMALE,
                "СПбГУ", "Матмех", "Математика");

        assertEquals(student1, student2);
        assertNotEquals(student1, student3);
        assertEquals(student1.hashCode(), student2.hashCode());
    }

    @Test
    public void testStudentInheritance() {
        Human human = new Human("Иванов", "Иван", "Иванович", 1990, Gender.MALE);
        Student student = new Student("Иванов", "Иван", "Иванович", 1990, Gender.MALE,
                "МГУ", "Физфак", "Физика");

        // Проверяем наследование полей
        assertEquals(human.getSurname(), student.getSurname());
        assertEquals(human.getName(), student.getName());
        assertEquals(human.getFather(), student.getFather());
        assertEquals(human.getYear(), student.getYear());
        assertEquals(human.getGender(), student.getGender());
    }
}