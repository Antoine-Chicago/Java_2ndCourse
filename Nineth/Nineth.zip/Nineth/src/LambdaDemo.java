import java.util.Arrays;
import java.util.function.*;
import java.util.stream.Collectors;

public class LambdaDemo {
    public static Function<String, Integer> getStringLength = String::length;

    public static Function<String, Character> getFirstChar =
            str -> str != null && !str.isEmpty() ? str.charAt(0) : null;

    public static Function<String, Boolean> noSpaces =
            str -> str != null && !str.isEmpty() ? !str.contains(" ") : null;

    //4 public static Function<String, Integer> countWordsByComma = s -> s.split(",").length;
    public static Function<String, Integer> countWordsByComma =
            s -> s == null ? 0 : (int) Arrays.stream(s.split(","))
                    .map(String::trim)  // Удалять пробелы
                    .filter(word -> !word.isEmpty())
                    .count();

    public static Function<Human, Integer> getHumanAge = Human::getYear; //5

    public static Function<Human, Function<Human, Boolean>> SameSurname =
            x1 -> (x2 -> (x1.getSurname().equals(x2.getSurname())));

    public static Function<Human, String> getFullName = //7
            x -> x.getSurname() + " " + x.getName() + " " + x.getFather();

    public static Function<Human, Human> makeOlder =
            x -> new Human(x.getSurname(), x.getName(), x.getFather(), 1 + x.getYear(), x.getGender());

    public static Function<Human, Function<Human, BiFunction<Human, Integer, Boolean>>> MaxAge =
            x1 -> (x2 -> ((x3, a) -> x1.getYear() < a && x2.getYear() < a && x3.getYear() < a));
}
