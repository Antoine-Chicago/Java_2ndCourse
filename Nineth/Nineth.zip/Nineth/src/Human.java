import java.util.Objects;

enum Gender {
    MALE("MALE"), FEMALE("FEMALE");

    private final String gender;

    Gender(String gender) {
        this.gender = gender;
    }

    public String getGender() {
        return gender;
    }
}

public class Human {
    private String surname, name, father;
    private int year;
    private Gender gender;

    public Human(String surname, String name, String father, int year, Gender gender){
        setSurname(surname);
        setName(name);
        setFather(father);
        setYear(year);
        setGender(gender);
    }

    public String getSurname() {return surname;}

    public String getName() {return name;}

    public String getFather() {return father;}

    public int getYear() {return year;}

    public void setSurname(String surname) {this.surname = surname;}

    public void setName(String name) {this.name = name;}

    public void setFather(String father) {this.father = father;}

    public void setYear(int year) { if (year <= 0) throw new IllegalArgumentException("Year <= 0\n"); this.year = year;}

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Human human = (Human) o;
        return year == human.year && Objects.equals(surname, human.surname) && Objects.equals(name, human.name) && Objects.equals(father, human.father) && Objects.equals(gender, human.gender);
    }

    @Override
    public int hashCode() {
        return Objects.hash(surname, name, father, year, gender);
    }
}
class Student extends Human{
    private String univer;
    private String faculty;
    private String special;

    public Student(String surname, String name, String father,  int year, Gender gender, String univer, String faculty, String special) {
        super(surname, name, father, year,gender);
        setUniver(univer);
        setFaculty(faculty);
        setSpecial(special);
    }
    public String getUniver() {
        return univer;
    }

    public String getFaculty() {
        return faculty;
    }

    public String getSpecial() {
        return special;
    }

    public void setUniver(String univer) {this.univer = univer;}

    public void setFaculty(String faculty) {this.faculty = faculty;}

    public void setSpecial(String special) {this.special = special;}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Student student = (Student) o;
        return Objects.equals(univer, student.univer) && Objects.equals(faculty, student.faculty) && Objects.equals(special, student.special);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), univer, faculty, special);
    }
}