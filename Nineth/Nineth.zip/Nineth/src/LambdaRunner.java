import java.util.function.BiFunction;
import java.util.function.Function;

public class LambdaRunner {
    public static <T, V> V lambdaRun(Function<T, V> lambda, T param) {
        try {
            return lambda.apply(param);
        } catch (NullPointerException ex) {
            return null;
        }
    }

    public static boolean twoHumanLambda(Function<Human, Function<Human, Boolean>> lambda, Human human1, Human human2) {
        return lambda.apply(human1).apply(human2);
    }

    public static boolean threeHumanLambda(
            Function<Human, Function<Human, BiFunction<Human, Integer, Boolean>>> lambda,
            Human human1, Human human2, Human human3, Integer maxAge) {
        return lambda.apply(human1).apply(human2).apply(human3, maxAge);
    }
}
