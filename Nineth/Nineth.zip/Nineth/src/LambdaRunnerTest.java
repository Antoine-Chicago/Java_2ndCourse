import org.junit.Test;
import java.util.Optional;
import static org.junit.Assert.*;

public class LambdaRunnerTest {
    @Test
    public void stringLengthTest() {
        assertEquals(Optional.of(7), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.getStringLength, "1234567")));
        assertEquals(Optional.of(0), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.getStringLength, "")));
        assertEquals(Optional.empty(), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.getStringLength, null)));
    }

    @Test
    public void firstCharacterTest() {
        assertEquals(Optional.of('1'), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.getFirstChar, "1234567")));
        assertEquals(Optional.empty(), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.getFirstChar, "")));
        assertEquals(Optional.empty(), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.getFirstChar, null)));
    }

    @Test
    public void noSpaceTest() {
        assertEquals(Optional.of(true), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.noSpaces, "1234567")));
        assertEquals(Optional.of(false), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.noSpaces, "12 34567")));
        assertEquals(Optional.of(false), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.noSpaces, " ")));
        assertEquals(Optional.empty(), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.noSpaces, "")));
        assertEquals(Optional.empty(), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.noSpaces, null)));
    }

    @Test
    public void numberOfWordsTest() {
        assertEquals(Optional.of(7), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.countWordsByComma, "1,2,3,4,5,6,7")));
        assertEquals(Optional.of(4), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.countWordsByComma, "12,,345,,6,,,7")));
        assertEquals(Optional.of(4), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.countWordsByComma, "12,, 345, ,,   ,6,, ,,7")));
        assertEquals(Optional.of(1), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.countWordsByComma, "1234567")));
        assertEquals(Optional.of(0), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.countWordsByComma, "")));
        assertEquals(Optional.of(0), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.countWordsByComma, null)));
    }

    @Test
    public void getAgeTest() {
        Human human1 = new Human("Ashaev", "Igor", "Victorovich", 49, Gender.MALE);
        Student student1 = new Student("Zhuravlev", "Anton", "Vladimirovich", 20, Gender.MALE,
                "OmGU", "MatFak", "Programmer");
        assertEquals(Optional.of(49), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.getHumanAge, human1)));
        assertEquals(Optional.of(20), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.getHumanAge, student1)));
    }

    @Test
    public void sameSurnameTest() {
        Human human1 = new Human("Zhuravel", "Anton", "Vladimirovich", 20, Gender.MALE);
        Student student1 = new Student("Zhuravel", "Daniil", "Andreevich", 25, Gender.MALE,
                "OmGU", "FCTK", "Programmer");
        Student student2 = new Student("AAA", "Danil", "Nicolaevich", 18, Gender.MALE,
                "OmGTU", "FITICS", "Programmer");
        assertEquals(Optional.of(true), Optional.of(LambdaRunner.twoHumanLambda(LambdaDemo.SameSurname, human1, student1)));
        assertEquals(Optional.of(false), Optional.of(LambdaRunner.twoHumanLambda(LambdaDemo.SameSurname, student2, student1)));
    }

    @Test
    public void fullNameTest() {
        Human human1 = new Human("Zhuravel", "Anton", "Vladimirovich", 19, Gender.MALE);
        Student student1 = new Student("Tesla", "Nikola", "", 48, Gender.MALE,
                "OmGUPS", "Trains", "Engineer");
        assertEquals(Optional.of("Zhuravel Anton Vladimirovich"), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.getFullName, human1)));
        assertEquals(Optional.of("Tesla Nikola "), Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.getFullName, student1)));
    }

    @Test
    public void makeOlderTest() {
        Human human1 = new Human("Zhuravel", "Anton", "Vladimirovich", 19, Gender.MALE);
        Student student1 = new Student("Larionov", "Sergey", "Pavlovich", 25, Gender.MALE,
                "OmGU", "IMIT", "Mathematician");
        assertEquals(Optional.of(new Human("Zhuravel", "Anton", "Vladimirovich", 20, Gender.MALE)),
                Optional.ofNullable(LambdaRunner.lambdaRun(LambdaDemo.makeOlder, human1)));
    }

    @Test
    public void youngerThanValueTest() {
        Human human1 = new Human("Zhuravlev", "Anton", "Vladimirovich", 20, Gender.MALE);
        Human human2 = new Human("Steklov", "Daniil", "Andreevich", 5, Gender.MALE);
        Human human3 = new Human("Markov", "Slava", "Romanovich", 28, Gender.MALE);
        assertEquals(
                Optional.of(true),
                Optional.of(LambdaRunner.threeHumanLambda(LambdaDemo.MaxAge, human1, human2, human3, 30))
        );
        assertEquals(
                Optional.of(false),
                Optional.of(LambdaRunner.threeHumanLambda(LambdaDemo.MaxAge, human1, human2, human3, 15))
        );
    }
}