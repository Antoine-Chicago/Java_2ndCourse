import java.util.Objects;

public class RationFunction implements IntFunctionOfX {
    private double a;
    private double b;
    private double k1;
    private double k2;
    private double k3;
    private double k4;

    public RationFunction(double a, double b, double k1, double k2, double k3, double k4) {
        setA(a);
        setB(b);
        setK1(k1);
        setK2(k2);
        setK3(k3);
        setK4(k4);
    }

    public void setA(double a) {
        this.a = a;
    }

    public void setB(double b) {
        this.b = b;
    }

    public void setK1(double k1) {
        this.k1 = k1;
    }

    public void setK2(double k2) {
        this.k2 = k2;
    }

    public void setK3(double k3) {
        this.k3 = k3;
    }

    public void setK4(double k4) {
        this.k4 = k4;
    }

    @Override
    public double getValue(double x) {
        if (x < this.a || x > this.b) throw new IllegalArgumentException("Function is out of segment scope\n");
        if (k1 * 1 + k2 == 0) return 0;
        else if ((k1 * x + k2) == (k3 * x + k4)) return 1;
        else if ((k3 * x + k4) == 0) throw new IllegalArgumentException("Function not defined\n");
        else return (k1 * x + k2) / (k3 * x + k4);
    }

    @Override
    public double[] getSegmentScope() {
        return new double[]{a, b};
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RationFunction that = (RationFunction) o;
        return Double.compare(that.a, a) == 0 && Double.compare(that.b, b) == 0 && Double.compare(that.k1, k1) == 0 && Double.compare(that.k2, k2) == 0 && Double.compare(that.k3, k3) == 0 && Double.compare(that.k4, k4) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(a, b, k1, k2, k3, k4);
    }
}
