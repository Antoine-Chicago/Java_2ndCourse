import java.util.Objects;
public class Integral<T extends IntFunctionOfX> implements Functional<T> {
    private double a;
    private double b;

    public Integral(double a, double b) throws IllegalArgumentException {
        if (a > b) throw new IllegalArgumentException("Function scope error\n");
        this.a = a;
        this.b = b;
    }

    @Override
    public double getValue(T func) throws IllegalArgumentException {
        long n = 2;//разбиение
        double result, tempResult = 0, h, eps = 1e-7;
        do {
            result = tempResult;
            tempResult = 0;
            n *= 3;
            h = (b - a) / n; //шаг
            for (int i = 0; i < n; i++) {
                double temp = tempResult + func.getValue(a + h / 2 + i * h) * h;
                if (Math.abs(temp - tempResult) > temp) {
                    break;
                } else {
                    tempResult = temp;
                }
            }
        } while (Math.abs(result - tempResult) > eps);//проверки точности вычислений
        return result;
    }
}
