import java.util.Objects;

public class LinearFunction implements IntFunctionOfX {
    private double a;
    private double b;
    private double k1;
    private double k2;

    public LinearFunction(double a, double b, double k1, double k2) {
        setA(a);
        setB(b);
        setK1(k1);
        setK2(k2);
    }

    public void setA(double a) {
        this.a = a;
    }

    public void setB(double b) {
        this.b = b;
    }

    public void setK1(double k1) {
        this.k1 = k1;
    }

    public void setK2(double k2) {
        this.k2 = k2;
    }

    @Override
    public double getValue(double x) {
        if (x < this.a || x > this.b) throw new IllegalArgumentException("Function is out of segment scope\n");
        return k1 * x + k2;
    }

    @Override
    public double[] getSegmentScope() {
        return new double[]{a, b};
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LinearFunction that = (LinearFunction) o;
        return Double.compare(that.a, a) == 0 && Double.compare(that.b, b) == 0 && Double.compare(that.k1, k1) == 0 && Double.compare(that.k2, k2) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(a, b, k1, k2);
    }
}
