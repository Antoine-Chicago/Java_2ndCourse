import java.util.Objects;

public class SumFunction<T extends IntFunctionOfX> implements Functional<T> {
    @Override
    public double getValue(T func) {
        return func.getValue(func.getSegmentScope()[0]) +
                func.getValue(func.getSegmentScope()[1]) +
                func.getValue((func.getSegmentScope()[0] + func.getSegmentScope()[1]) / 2);
    }
}
