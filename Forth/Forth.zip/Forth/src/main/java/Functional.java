public interface Functional<T extends IntFunctionOfX> {

   double getValue(T function);
}
