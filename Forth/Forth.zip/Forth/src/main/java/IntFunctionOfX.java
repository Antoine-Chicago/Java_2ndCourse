public interface IntFunctionOfX {
    double getValue(double x);
    double[] getSegmentScope();
}
