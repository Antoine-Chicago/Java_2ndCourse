import org.junit.Test;

import static org.junit.Assert.*;

public class SumFunctionTest {
    SumFunction<IntFunctionOfX> function = new SumFunction<>();
    @Test
    public void GetValue() {
        assertTrue(Math.abs(3 - function.getValue(new LinearFunction(0, 2, 1, 0))) < 1e-9);
        assertTrue(Math.abs(1.32089652341 - function.getValue(new Sinus(0, 1, 1, 1))) < 1e-9);
        assertTrue(Math.abs(3 - function.getValue(new RationFunction(0, 2, 1, 0, 1, 0))) < 1e-9);
        assertTrue(Math.abs(0 - function.getValue(new RationFunction(0, 2, 0, 0, 1, 0))) < 1e-9);
        assertTrue(Math.abs(11.1073379274 - function.getValue(new ExponentialFunction(0, 2, 1, 0))) < 1e-9);
    }
}