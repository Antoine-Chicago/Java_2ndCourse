import org.junit.Test;
import static org.junit.Assert.*;

public class IntegralTest {
    @Test
    public void getValue() {
        assertEquals(0.4596976941318603, new Integral<Sinus>(0, 1).getValue(new Sinus(0, 3, 1, 1)), 10e-8);
        assertEquals(2, new Integral<Sinus>(0, Math.PI).getValue(new Sinus(-10, 10, 1, 1)), 1e-5);
        assertEquals(2, new Integral<LinearFunction>(0, 2).getValue(new LinearFunction(-10, 10, 1, 0)), 1e-5);
        assertEquals(Math.exp(2) - 1, new Integral<ExponentialFunction>(0, 2).getValue(new ExponentialFunction(-10, 10, 1, 0)), 10e-8);

    }
    @Test
    public void getValueRation_0(){
        new Integral<RationFunction>(0, 3.14);

        try {
            RationFunction function = new RationFunction(-10, 10, 1, 1,0,0);//знаменатель 0
        } catch (ArithmeticException c){
            System.err.println("Integral isn't defined");
        }
    }
}