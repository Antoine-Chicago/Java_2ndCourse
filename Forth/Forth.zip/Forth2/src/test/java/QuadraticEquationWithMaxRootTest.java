import org.junit.Test;

import static org.junit.Assert.*;

public class QuadraticEquationWithMaxRootTest {
    @Test
    public void testGetMaxRootNoRealRoots() {
        QuadraticEquation equation = new QuadraticEquation(1, 2, 3);
        QuadraticEquationWithMaxRoot trinomial = new QuadraticEquationWithMaxRoot(equation);
        assertThrows(IllegalArgumentException.class, trinomial::getMaxRoot);
    }

    @Test
    public void testGetMaxRootOneRealRoot() {
        QuadraticEquation equation = new QuadraticEquation(1, 2, 1);
        QuadraticEquationWithMaxRoot trinomial = new QuadraticEquationWithMaxRoot(equation);

        assertEquals(-1, trinomial.getMaxRoot(), 0.0001);
    }

    @Test
    public void testGetMaxRootTwoRealRoots() {
        QuadraticEquation equation = new QuadraticEquation(1, -2, 1);
        QuadraticEquationWithMaxRoot trinomial = new QuadraticEquationWithMaxRoot(equation);

        assertEquals(1, trinomial.getMaxRoot(), 0.0001);
    }
}