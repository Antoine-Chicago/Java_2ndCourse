import java.util.Objects;

public class QuadraticEquationWithMaxRoot  {
    private QuadraticEquation trinomial;

    public QuadraticEquationWithMaxRoot(QuadraticEquation trinomial) { //с максимальным корнем
        this.trinomial = trinomial;
    }

    public double getMaxRoot() {
        double[] roots = trinomial.solve();
        if (roots.length == 0) {
            throw new IllegalArgumentException("Уравнение не имеет действительных корней.");
        } else if (roots.length == 1) {
            return roots[0]; // Возвращаем единственный корень
        } else {
            return Math.max(roots[0], roots[1]); // Возвращаем наибольший корень
        }
    }
}
