import org.junit.Test;

import static org.junit.Assert.*;

public class FilterTest {
    @Test
    public void beginStringFilter() {
        assertTrue(new BeginStringFilter("aab").apply("aabcdefg"));
        assertFalse(new BeginStringFilter("alb").apply("achabdef"));
        assertTrue(new BeginStringFilter("").apply(""));
        assertFalse(new BeginStringFilter("food").apply(""));
    }

    @Test
    public void endStringFilter() {
        assertTrue(new EndStringFilter("aab").apply("aacdefgaab"));
        assertFalse(new EndStringFilter("aab").apply("acabcdefgaa"));
        assertTrue(new EndStringFilter("").apply(""));
        assertFalse(new EndStringFilter("food").apply(""));
    }

    @Test
    public void compareStringFilter() {
        assertTrue(new CompareStringFilter("aabc").apply("aabd"));
        assertFalse(new CompareStringFilter("acabad").apply("aca"));
        assertTrue(new CompareStringFilter("").apply(""));
        assertFalse(new CompareStringFilter("acab").apply(""));
    }
}