import org.junit.Test;

import static org.junit.Assert.*;

public class ProductServiceTest {
    Consignment consignment1 = new Consignment(
            "Brick and Sand",
            new Packable[]{
                    new PackagedPieceProduct( //упаков.штучный
                            new PieceProduct("Brick", "Huge", 40),
                            new ProductPackaging("Linen bags", 2),
                            20
                    ),
                    new PackagedWeightedProduct( //упаков.весовой
                            new WeightProduct("Sand", "Yellow"),
                            300,
                            new ProductPackaging("Polyethylene bags", 2)
                    )
            }
    );
    Consignment consignment2 = new Consignment(
            "Stone and Sand",
            new Packable[]{
                    new PackagedPieceProduct( //упаков.штучный
                            new PieceProduct("Stone", "Huge", 40),
                            new ProductPackaging("Linen bags", 2),
                            20
                    ),
                    new PackagedWeightedProduct( //упаков.весовой
                            new WeightProduct("Sand", "Yellow"),
                            300,
                            new ProductPackaging("Polyethylene bags", 2)
                    ),
                    new PackagedSetOfProducts( //упаков.набор товаров
                            new ProductPackaging("Polyethylene bags", 8),
                            new Packable[]{
                                    new PackagedPieceProduct(
                                            new PieceProduct("Stone", "Hard", 30),
                                            new ProductPackaging("Linen bags", 1),
                                            20
                                    ),
                                    new PackagedWeightedProduct(
                                            new WeightProduct("Sand", "Yellow"),
                                            300,
                                            new ProductPackaging("Polyethylene bags", 2)
                                    )
                            },
                            "Stone and Sand"
                    )
            }
    );
    Consignment consignment3 = new Consignment(
            "Build Materials",
            new Packable[]{
                    new PackagedPieceProduct( //упаков.штучный
                            new PieceProduct("Brick", "Huge", 40), //count +1
                            new ProductPackaging("Linen bags", 2),
                            20
                    ),
                    new PackagedWeightedProduct( //упаков.весовой
                            new WeightProduct("Brick", "Red"), //count +2
                            300,
                            new ProductPackaging("Polyethylene bags", 2)
                    ),
                    new PackagedSetOfProducts( //упаков.набор товаров
                            new ProductPackaging("Polyethylene bags", 8),
                            new Packable[]{
                                    new PackagedPieceProduct(
                                            new PieceProduct("Brick", "Hard", 30), //count const
                                            new ProductPackaging("Linen bags", 1),
                                            20
                                    ),
                                    new PackagedWeightedProduct(
                                            new WeightProduct("Brick", "Yellow"), //count const
                                            300,
                                            new ProductPackaging("Polyethylene bags", 2)
                                    )
                            },
                            "Brick") //count +3
            }
    );

    @Test
    public void CountByFilter() {
        assertEquals(0, ProductService.countByFilter(consignment1, new BeginStringFilter("ri")));
        assertEquals(1, ProductService.countByFilter(consignment1, new BeginStringFilter("Bri")));
    }

    @Test
    public void CountByFilter2() {
        assertEquals(0, ProductService.countByFilter(consignment2, new BeginStringFilter("to")));
        assertEquals(2, ProductService.countByFilter(consignment2, new BeginStringFilter("Sto")));
    }

    @Test
    public void CountByFilter3() {
        assertEquals(0, ProductService.countByFilter(consignment3, new BeginStringFilter("ic")));
        assertEquals(3, ProductService.countByFilter(consignment3, new BeginStringFilter("Brick")));
    }

    /*Consignment consignment2 = new Consignment(
            "Stones and Sand",
            new Packable[]{
                    new PackagedWeightedProduct(
                            new WeightProduct("Sugar", "White"),
                            300,
                            new ProductPackaging("Polyethylene bags", 2)
                    ),
                    new PackagedWeightedProduct(
                            new WeightProduct("Sand", "Yellow"),
                            300,
                            new ProductPackaging("Polyethylene bags", 2)
                    ),
                    new PackagedSetOfProducts(
                            new ProductPackaging("Polyethylene bags", 8),
                            new Packable[]{
                                    new PackagedWeightedProduct(
                                            new WeightProduct("Salt", "Big"),
                                            300,
                                            new ProductPackaging("Polyethylene bags", 2)
                                    ),
                                    new PackagedWeightedProduct(
                                            new WeightProduct("Pepper", "Black"),
                                            300,
                                            new ProductPackaging("Polyethylene bags", 2)
                                    )
                            },
                            "Stones and Sand"
                    )
            }
    );
    Consignment consignment3 = new Consignment(
            "Stones and Sand",
            new Packable[]{
                    new PackagedWeightedProduct(
                            new WeightProduct("Sugar", "White"),
                            300,
                            new ProductPackaging("Polyethylene bags", 2)
                    ),
                    new PackagedWeightedProduct(
                            new WeightProduct("Sand", "Yellow"),
                            300,
                            new ProductPackaging("Polyethylene bags", 2)
                    ),
                    new PackagedSetOfProducts(
                            new ProductPackaging("Polyethylene bags", 8),
                            new Packable[]{
                                    new PackagedSetOfProducts(
                                            new ProductPackaging("Polyethylene bags", 8),
                                            new Packable[]{
                                                    new PackagedWeightedProduct(
                                                            new WeightProduct("Salt", "Big"),
                                                            300,
                                                            new ProductPackaging("Polyethylene bags", 2)
                                                    ),
                                                    new PackagedWeightedProduct(
                                                            new WeightProduct("Pepper", "Black"),
                                                            300,
                                                            new ProductPackaging("Polyethylene bags", 2)
                                                    )
                                            },
                                            "Stones and Sand"
                                    ),
                                    new PackagedWeightedProduct(
                                            new WeightProduct("Pepper", "Black"),
                                            300,
                                            new ProductPackaging("Polyethylene bags", 2)
                                    )
                            },
                            "Stones and Sand"
                    )
            }
    );*/

    /*@Test
    public void CountByFilterDeep() {
        assertEquals(2, ProductService.countByFilterDeep(consignment1, new BeginStringFilter("Bri")));
        assertEquals(1, ProductService.countByFilterDeep(consignment2, new BeginStringFilter("Salt")));
        assertEquals(1, ProductService.countByFilterDeep(consignment3, new BeginStringFilter("Salt")));
    }

    @Test
    public void CheckAllWeighted() {
        assertFalse(ProductService.checkAllWeighted(consignment1));
        assertTrue(ProductService.checkAllWeighted(consignment2));
    }*/
}