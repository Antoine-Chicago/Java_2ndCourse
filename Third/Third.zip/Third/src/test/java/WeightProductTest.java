import org.junit.Test;

import static org.junit.Assert.*;

public class WeightProductTest {

    @Test
    public void testWeightProduct() {
        WeightProduct weightProduct = new WeightProduct("Phone", "Samsung");
        assertEquals(weightProduct, new WeightProduct("Phone", "Samsung"));
        System.out.println(weightProduct);
        weightProduct.setDescription("Iphone");
        assertEquals(weightProduct, new WeightProduct("Phone", "Iphone"));
        assertEquals("WeightProduct{'Phone', 'Iphone'}", weightProduct.toString());
        System.out.print(weightProduct);
    }
}