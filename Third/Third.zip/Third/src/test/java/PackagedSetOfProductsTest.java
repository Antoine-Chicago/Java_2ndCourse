import org.junit.Test;

import static org.junit.Assert.*;

public class PackagedSetOfProductsTest { // Упакованный набор товаров
    PackagedSetOfProducts setOfProducts = new PackagedSetOfProducts(
            new ProductPackaging("Polyethylene bags", 8),
            new Packable[]{
                    new PackagedPieceProduct(
                            new PieceProduct("Stone", "Hard", 40),
                            new ProductPackaging("Linen bags", 1),
                            20
                    ),
                    new PackagedWeightedProduct(
                            new WeightProduct("Sand", "Yellow"),
                            300,
                            new ProductPackaging("Polyethylene bags", 2)
                    )
            },
            "Stones and Sand"
    );

    @Test
    public void getNetMass() {
        assertTrue(setOfProducts.getNetMass() - 1122 < 1e-9);
    }

    @Test
    public void getGrossMass() {
        assertTrue(setOfProducts.getNetMass() - 1130 < 1e-9);
    }

    @Test
    public void packagedSetOfProducts() {
        assertEquals("PackagedSetOfProducts{" +
                        "productPackage=ProductPackage{'Polyethylene bags', 8.0kg.}, " +
                        "setOfProducts=[" +
                        "PackagedPieceProduct{PieceProduct{'Stone', 'Hard', 40.0kg.}, ProductPackage{'Linen bags', 1.0kg.}, numberOfProducts=20}, " +
                        "PackagedWeightedProduct{WeightProduct{'Sand', 'Yellow'}, ProductPackage{'Polyethylene bags', 2.0kg.}, 300.0kg.}" +
                        "], " +
                        "name='Stones and Sand'}",
                setOfProducts.toString()
        );
    }
}