import org.junit.Test;

import static java.lang.Math.pow;
import static org.junit.Assert.*;

public class ConsignmentTest {
    Consignment consignment = new Consignment(
            "Stones and Sand",
            new Packable[]{
                    new PackagedPieceProduct( //штучный товар упакованный
                            new PieceProduct("Stone", "Hard", 40),
                            new ProductPackaging("Linen bags", 1),
                            20
                    ),
                    new PackagedWeightedProduct( //весовой товар упакованный
                            new WeightProduct("Sand", "Yellow"),
                            300,
                            new ProductPackaging("Polyethylene bags", 2)
                    ),
                    new PackagedSetOfProducts( //Весь набор
                            new ProductPackaging("Polyethylene bags", 8),
                            new Packable[]{
                                    new PackagedPieceProduct(
                                            new PieceProduct("Stone", "Hard", 40),
                                            new ProductPackaging("Linen bags", 1),
                                            20
                                    ),
                                    new PackagedWeightedProduct(
                                            new WeightProduct("Sand", "Yellow"),
                                            300,
                                            new ProductPackaging("Polyethylene bags", 2)
                                    )
                            },
                            "Stones and Sand"
                    )
            }
    );

    @Test
    public void getOverallMass() {
        System.out.print("Proof: " + consignment.getOverallMass());
        assertTrue(consignment.getOverallMass() - 2252 < pow(10,6));
    }

    @Test
    public void consignment() {
        assertEquals("Consignment{" +
                "description='Stones and Sand', " +
                "setOfProducts=[" +
                "PackagedPieceProduct{" +
                "PieceProduct{'Stone', 'Hard', 40.0kg.}, " +
                "ProductPackage{'Linen bags', 1.0kg.}, " +
                "numberOfProducts=20" +
                "}, " +
                "PackagedWeightedProduct{" +
                "WeightProduct{'Sand', 'Yellow'}, " +
                "ProductPackage{'Polyethylene bags', 2.0kg.}, " +
                "300.0kg." +
                "}, " +
                "PackagedSetOfProducts{" +
                "productPackage=ProductPackage{'Polyethylene bags', 8.0kg.}, " +
                "setOfProducts=[" +
                "PackagedPieceProduct{" +
                "PieceProduct{'Stone', 'Hard', 40.0kg.}, " +
                "ProductPackage{'Linen bags', 1.0kg.}, " +
                "numberOfProducts=20" +
                "}, " +
                "PackagedWeightedProduct{" +
                "WeightProduct{'Sand', 'Yellow'}, " +
                "ProductPackage{'Polyethylene bags', " +
                "2.0kg." +
                "}, " +
                "300.0kg." +
                "}" +
                "], " +
                "name='Stones and Sand'" +
                "}" +
                "]" +
                "}", consignment.toString());
    }
}