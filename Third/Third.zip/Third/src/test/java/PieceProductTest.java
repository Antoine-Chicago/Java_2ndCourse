import org.junit.Test;

import static java.lang.StrictMath.pow;
import static org.junit.Assert.*;

public class PieceProductTest {
    @Test
    public void testPieceProduct() {
        PieceProduct product = new PieceProduct("Nails", "Sharp", 12);
        assertEquals(product, new PieceProduct("Nails", "Sharp", 12));
        assertTrue(product.getWeight() - 12 < pow(10,9));
        product.setWeight(5);
        assertEquals(product, new PieceProduct("Nails", "Sharp", 5));
        assertThrows(IllegalArgumentException.class, () -> product.setWeight(-1));
        assertEquals("PieceProduct{'Nails', 'Sharp', 5.0kg.}", product.toString());
    }
}