import org.junit.Test;

import static org.junit.Assert.*;

public class PackagedPieceProductTest {

    @Test
    public void getNetMass() {
        PackagedPieceProduct product = new PackagedPieceProduct(
                new PieceProduct("Phone", "Samsung", 5),
                new ProductPackaging("Paper", 3),
                5
        );
        assertTrue(product.getNetMass() - 25 < 1e-9);
    }

    @Test
    public void getGrossMass() {
        PackagedPieceProduct product = new PackagedPieceProduct(
                new PieceProduct("Phone", "Samsung", 5),
                new ProductPackaging("Paper", 3),
                5);
        assertTrue(product.getGrossMass() - 40 < 1e-9);
    }

    @Test
    public void packagedPieceProduct() {
        PackagedPieceProduct product = new PackagedPieceProduct(
                new PieceProduct("Apples", "Red", 5),
                new ProductPackaging("Paper", 3),
                5
        );
        assertEquals("PackagedPieceProduct{PieceProduct{'Apples', 'Red', 5.0kg.}, " +
                        "ProductPackage{'Paper', 3.0kg.}, numberOfProducts=5}",
                product.toString());
    }
}