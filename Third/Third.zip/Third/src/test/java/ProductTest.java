import org.junit.Test;
import static org.junit.Assert.*;

public class ProductTest {

    @Test
    public void testNullName() {
        Product product = new Product(null, "Red, Krasnodar's");
        assertNotEquals("Некорректное название товара",product.toString());
    }

    @Test
    public void testNullDescription() {
        Product product = new Product("Apple", null);
        assertNotEquals("Некорректное описание товара",product.toString());
    }

    @Test
    public void testFull() {
        Product product = new Product("Apple", "Green, Siberian");
        assertEquals("Product{name='Apple', description='Green, Siberian'}",product.toString());
    }

}