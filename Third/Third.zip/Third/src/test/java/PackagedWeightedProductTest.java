import org.junit.Test;

import static java.lang.Math.pow;
import static org.junit.Assert.*;

public class PackagedWeightedProductTest{

    @Test
    public void getNetMass() {
        assertThrows(IllegalArgumentException.class, () -> new PackagedWeightedProduct(
                new WeightProduct("Sugar", "Sweet"),
                -30,
                new ProductPackaging("Paper", 1)
        ));
        PackagedWeightedProduct product = new PackagedWeightedProduct(
                new WeightProduct("Sugar", "Sweet"),
                10,
                new ProductPackaging("Paper", 1)
        );
        assertTrue(product.getNetMass() - 10 < pow(10,6));
    }

    @Test
    public void getGrossMass() {
        PackagedWeightedProduct product = new PackagedWeightedProduct(
                new WeightProduct("Lemon", "Bitter"),
                1,
                new ProductPackaging("Potato", 1)
        );
        assertTrue(product.getGrossMass() - 2 < pow(10,6));
    }

    @Test
    public void packagedWeightedProduct() {
        PackagedWeightedProduct product = new PackagedWeightedProduct(
                new WeightProduct("Sugar", "Sweet"),
                13,
                new ProductPackaging("Paper", 4.9)
        );
        assertEquals("PackagedWeightedProduct{WeightProduct{'Sugar', 'Sweet'}, " +
                        "ProductPackage{'Paper', 4.9kg.}, 13.0kg.}",
                product.toString());
    }
}