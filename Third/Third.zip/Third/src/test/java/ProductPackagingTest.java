import org.junit.Test;

import static java.lang.StrictMath.pow;
import static org.junit.Assert.*;

public class ProductPackagingTest {
    @Test
    public void testProductPackage() {
        ProductPackaging productPackage = new ProductPackaging("Carbon", 15);
        assertEquals(productPackage, new ProductPackaging("Carbon", 15));
        assertEquals(productPackage.getName(), "Carbon");
        assertTrue(productPackage.getWeight() - 15 < pow(10,9));
        assertThrows(IllegalArgumentException.class, () -> productPackage.setWeight(-1));
        assertEquals("ProductPackage{'Carbon', 15.0kg.}", productPackage.toString());
    }
}