import java.util.Arrays;
import java.util.Objects;

public class Consignment { // Партия товаров
    private String description;
    private Packable[] setOfProducts;

    public Consignment(String description, Packable[] setOfProducts) {
        setDescription(description);
        setSetOfProducts(setOfProducts);
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Packable[] getSetOfProducts() { //произвольный набор упакованных товаров
        return setOfProducts;
    }

    public void setSetOfProducts(Packable[] setOfProducts) {
        this.setOfProducts = new Packable[setOfProducts.length];
        for (int i = 0; i < setOfProducts.length; i++) {
            this.setOfProducts[i] = setOfProducts[i].create();
        }
    }

    public double getOverallMass() { //Суммарная масса брутто всех товаров в партии
        double mass = 0;
        for (Packable setOfProduct : setOfProducts) {
            mass += setOfProduct.getGrossMass();
        }
        return mass;
    }

    @Override
    public String toString() {
        return "Consignment{" +
                "description='" + description + '\'' +
                ", setOfProducts=" + Arrays.toString(setOfProducts) +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Consignment that = (Consignment) o;
        return Objects.equals(description, that.description) && Arrays.equals(setOfProducts, that.setOfProducts);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(description);
        result = 31 * result + Arrays.hashCode(setOfProducts);
        return result;
    }
}

