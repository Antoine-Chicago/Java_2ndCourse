import java.util.Arrays;
import java.util.Objects;

public class PackagedSetOfProducts implements Packable { //Упакованный набор товаров
    private ProductPackaging productPackage; //упаковка
    private Packable[] setOfProducts; //набор
    private String name;

    public PackagedSetOfProducts(ProductPackaging productPackage, Packable[] setOfProducts, String name) {
        setProductPackage(productPackage);
        setSetOfProducts(setOfProducts);
        setName(name);
    }

    @Override
    public ProductPackaging getProductPackage() {
        return productPackage;
    }

    @Override
    public void setProductPackage(ProductPackaging productPackage) {
        this.productPackage = productPackage;
    }

    public Packable[] getSetOfProducts() {
        return setOfProducts;
    }

    public void setSetOfProducts(Packable[] setOfProducts) {
        this.setOfProducts = new Packable[setOfProducts.length];
        for (int i = 0; i < setOfProducts.length; i++) {
            this.setOfProducts[i] = setOfProducts[i].create();
        }
    }

    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public double getNetMass() {
        double weight = 0;
        for (Packable i : setOfProducts) {
            weight += i.getGrossMass();
        }
        return weight;
    }

    @Override
    public double getGrossMass() {
        return getNetMass() + getProductPackage().getWeight();
    }

    @Override
    public Packable create() {
        return new PackagedSetOfProducts(getProductPackage(), getSetOfProducts(), getName());
    }

    @Override
    public boolean isWeighted() {
        for (Packable i : setOfProducts) {
            if (!i.isWeighted()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public Consignment getConsignment() {
        return new Consignment("", this.setOfProducts);
    }

    @Override
    public String toString() {
        return "PackagedSetOfProducts{" +
                "productPackage=" + productPackage +
                ", setOfProducts=" + Arrays.toString(setOfProducts) +
                ", name='" + name + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PackagedSetOfProducts that = (PackagedSetOfProducts) o;
        return Objects.equals(productPackage, that.productPackage) && Arrays.equals(setOfProducts, that.setOfProducts);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(productPackage);
        result = 31 * result + Arrays.hashCode(setOfProducts);
        return result;
    }
}