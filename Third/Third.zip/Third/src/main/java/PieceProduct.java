import java.util.Objects;

public class PieceProduct extends Product { // Штучный товар
    private double weight;

    public PieceProduct(String name, String description, double weight) {
        super(name, description);
        setWeight(weight);
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        if (weight <= 0) throw new IllegalArgumentException("The weight is <= 0\n");
        this.weight = weight;
    }

    @Override
    public String toString() {
        return "PieceProduct{" +
                '\'' + getName() + '\'' +
                ", '" + getDescription() + '\'' +
                ", " + weight +
                "kg.}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        PieceProduct that = (PieceProduct) o;
        return Double.compare(that.weight, weight) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), weight);
    }
}

