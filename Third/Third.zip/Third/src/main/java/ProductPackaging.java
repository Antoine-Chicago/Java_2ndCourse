import java.util.Objects;

public class ProductPackaging { // Упаковка товара
    private String name;
    private double weight;

    public ProductPackaging(String name, double weight) {
        setName(name);
        setWeight(weight);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        if (weight <= 0) throw new IllegalArgumentException("The weight of package <= 0\n");
        this.weight = weight;
    }

    @Override
    public String toString() {
        return "ProductPackage{" +
                '\'' + name + '\'' +
                ", " + weight +
                "kg.}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductPackaging that = (ProductPackaging) o;
        return Double.compare(that.weight, weight) == 0 && Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, weight);
    }
}
