import java.util.Arrays;
import java.util.Objects;

public class WeightProduct extends Product { // Весовой товар
    public WeightProduct(String name, String description) {
        super(name, description);
    }

    @Override
    public String toString() {
        return "WeightProduct{" +
                '\'' + getName() + '\'' +
                ", '" + getDescription() + '\'' +
                '}';
    }
}
