import java.util.Objects;

public class PackagedPieceProduct extends PieceProduct implements Packable { //Упакованный штучный товар
    private ProductPackaging productPackage;
    private int numberOfProducts;

    public PackagedPieceProduct(PieceProduct product, ProductPackaging productPackage, int numberOfProducts) {
        super(product.getName(), product.getDescription(), product.getWeight());
        setProductPackage(productPackage);
        setNumberOfProducts(numberOfProducts);
    }

    @Override
    public ProductPackaging getProductPackage() {
        return productPackage;
    }

    @Override
    public void setProductPackage(ProductPackaging productPackage) {
        this.productPackage = productPackage;
    }

    public int getNumberOfProducts() {
        return numberOfProducts;
    }

    public void setNumberOfProducts(int numberOfProducts) {
        this.numberOfProducts = numberOfProducts;
    }

    @Override
    public double getNetMass() {
        return getNumberOfProducts() * getWeight();
    }

    @Override
    public double getGrossMass() {
        return getNumberOfProducts() * getProductPackage().getWeight() + getNetMass();
    }

    @Override
    public Packable create() {
        return new PackagedPieceProduct(new PieceProduct(getName(), getDescription(), getWeight()), getProductPackage(), getNumberOfProducts());
    }

    @Override
    public boolean isWeighted() {
        return false;
    }

    @Override
    public Consignment getConsignment() {
        return null;
    }

    @Override
    public String toString() {
        return "PackagedPieceProduct{" + new PieceProduct(getName(), getDescription(), getWeight()) +
                ", " + productPackage.toString() +
                ", numberOfProducts=" + numberOfProducts +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        PackagedPieceProduct that = (PackagedPieceProduct) o;
        return numberOfProducts == that.numberOfProducts && Objects.equals(productPackage, that.productPackage);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), productPackage, numberOfProducts);
    }
}
