import java.util.Objects;

public class PackagedWeightedProduct extends WeightProduct implements Packable { //Упакованный весовой товар
    private ProductPackaging productPackage; //Упаковка товара
    private double productWeight; //масса товара

    // упаковка и некоторое количество весового товара
    public PackagedWeightedProduct(WeightProduct product, double productWeight, ProductPackaging productPackage) {
        super(product.getName(), product.getDescription());
        setProductPackage(productPackage);
        setProductWeight(productWeight);
    }

    @Override
    public ProductPackaging getProductPackage() {
        return productPackage;
    }

    @Override
    public void setProductPackage(ProductPackaging productPackage) {
        this.productPackage = productPackage;
    }

    public double getProductWeight() {
        return productWeight;
    }

    public void setProductWeight(double productWeight) {
        if (productWeight <= 0) throw new IllegalArgumentException("The weight of product <= 0\n");
        this.productWeight = productWeight;
    }

    @Override
    public double getNetMass() { //массу нетто (только товара)
        return getProductWeight();
    }

    @Override
    public double getGrossMass() { //массу брутто (упаковки и товара вместе).
        return getNetMass() + productPackage.getWeight();
    }

    @Override
    public Packable create() {
        return new PackagedWeightedProduct(new WeightProduct(getName(), getDescription()), getProductWeight(), getProductPackage());
    }

    @Override
    public String toString() {
        return "PackagedWeightedProduct{" + new WeightProduct(getName(), getDescription()) +
                ", " + productPackage.toString() +
                ", " + productWeight + "kg." +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        PackagedWeightedProduct that = (PackagedWeightedProduct) o;
        return Double.compare(that.productWeight, productWeight) == 0 && Objects.equals(productPackage, that.productPackage);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), productPackage, productWeight);
    }
    @Override
    public boolean isWeighted() {
        return true;
    }

    @Override
    public Consignment getConsignment() {
        return null;
    }
}
