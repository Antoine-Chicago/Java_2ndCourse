public interface Packable {

    ProductPackaging getProductPackage();

    void setProductPackage(ProductPackaging productPackage);

    double getNetMass();

    double getGrossMass();

    Packable create();

    String getName();

    boolean isWeighted();

    Consignment getConsignment();
}
