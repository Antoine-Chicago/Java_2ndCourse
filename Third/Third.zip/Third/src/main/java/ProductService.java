import java.util.Objects;

public class ProductService {
    /*public static int countByFilter0(Consignment consignment, Filter filter) {
        int count = 0; //количество элементов партии
        for (Packable i : consignment.getSetOfProducts()) {
            if (filter.apply(i.getName())) {
                count++;
            }
        }
        return count;
    }*/

    public static int countByFilter(Consignment consignment, Filter filter) {
        int count = 0; //количество элементов партии
        for (Packable i : consignment.getSetOfProducts()) {
            if (filter.apply(i.getName())) {
                count++;
            }
        }
        return count;
    }

    /*public static int countByFilterDeep(Consignment consignment, Filter filter) {
        int count = 0;
        for (Packable i : consignment.getSetOfProducts()) {
            if (i.getConsignment() != null) {
                count += countByFilterDeep(i.getConsignment(), filter);
            } else if (filter.apply(i.getName())) {
                count++;
            }
        }
        return count;
    }

    public static boolean checkAllWeighted(Consignment consignment) {
        for (Packable i : consignment.getSetOfProducts()) {
            if (!i.isWeighted()) {
                return false;
            }
        }
        return true;
    }*/
}
