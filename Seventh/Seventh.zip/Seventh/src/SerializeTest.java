import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import org.junit.jupiter.api.Test;
import java.io.*;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class SerializeTest {
    @Test
    public void testSerializeAndDeserializeHouse() throws IOException, ClassNotFoundException {
        // Подготовка данных
        Person elder = new Person("Иванов", "Аркадий", "Петрович", 27, 1, 2005);
        Flat flat = new Flat(1, 58.5, List.of(elder));
        House originalHouse = new House("123ABC", "ул. Ленина, 1", elder, List.of(flat));

        // Сериализация
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Serialize.serializeHouse(originalHouse, baos);

        // Десериализация
        ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
        House deserializedHouse = Serialize.deserializeHouse(bais);

        // Проверка (используем equals())
        assertEquals(originalHouse, deserializedHouse);
        assertEquals(originalHouse.getCadaster(), deserializedHouse.getCadaster());
        assertEquals(originalHouse.getAddress(), deserializedHouse.getAddress());
        assertEquals(originalHouse.getAdmin(), deserializedHouse.getAdmin()); //старший дома
        assertEquals(originalHouse.getFlats(), deserializedHouse.getFlats());
    }
}