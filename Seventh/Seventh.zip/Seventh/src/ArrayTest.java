import org.junit.Test;
import java.io.*;
import org.junit.jupiter.api.io.TempDir;
import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.*;
import java.nio.file.Files;

public class ArrayTest {
    @Test
    public void testWriteBinaryStream() throws IOException {
        int[] data = {1, 2, 3};
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        Array.write_BinaryStream(data, baos);// Запись данных

        byte[] resultBytes = baos.toByteArray();

        assertEquals(data.length * Integer.BYTES, resultBytes.length);// Проверяем количество байтов
    }

    @Test
    public void testReadBinaryStream() throws IOException {
        int[] data = {1, 2, 3};

        // Создаем поток с данными для чтения
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);

        // Записываем данные в поток
        for (int num : data) {
            dos.writeInt(num);
        }

        // Создаем входной поток на основе записанных данных
        ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());

        int[] readData = new int[data.length];
        Array.read_BinaryStream(readData, bais); // Считываем числа из потока

        assertArrayEquals(data, readData); // Проверяем, что считанные данные == исходным
    }

    @Test
    public void testWriteCharStream() throws IOException {
        char[] chars = {'A', 'B', 'C'};
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Array.write_CharStream(chars, new OutputStreamWriter(baos));//Запись символы в файл, разделяя пробелами.

        String expectedResult = "A B C ";
        assertEquals(expectedResult, baos.toString("UTF-8"));
    }

    @Test
    public void testReadCharStream() throws IOException {
        char[] chars = {'X', 'Y', 'Z'};
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Array.write_CharStream(chars, new OutputStreamWriter(baos));

        ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
        CharArrayReader car = new CharArrayReader(new String(bais.readAllBytes(), "UTF-8").toCharArray());

        CharArrayWriter actualBuf = Array.read_CharStream(chars, car);//Читает символьный массив

        String expectedContent = "X Y Z ";
        assertEquals(expectedContent, actualBuf.toString());
    }

    @Test
    public void testEmptyArray() throws IOException {

        int[] emptyArr = {};

        ByteArrayOutputStream OutStream = new ByteArrayOutputStream();
        Array.write_BinaryStream(emptyArr, OutStream); // Запись пустой массив

        ByteArrayInputStream InStream = new ByteArrayInputStream(OutStream.toByteArray());

        int[] resultArr = new int[emptyArr.length]; // Массив нулевого размера
        Array.read_BinaryStream(resultArr, InStream); //читает из пустого потока

        assertArrayEquals(emptyArr, resultArr); //получить пустой массив

    }

    @Test
    public void testRandomAccessFile() throws IOException{
        String filePath = "numbers.txt";
        long startPosition = 8;
        int numbersToRead = 3;

        try {
            DataOutputStream dos = new DataOutputStream(new FileOutputStream("numbers.txt"));
            for (int i = 1; i <= 5; i++) {
                dos.writeInt(i); // Записываем числа в бинарном формате
            }
            int[] numbers = Array.readFromPosition(filePath, startPosition, numbersToRead);

            System.out.println("Прочитанные числа:");
            for (int num : numbers) {
                System.out.println(num);
            }

        } catch (IOException e) {
            System.err.println("Ошибка при чтении файла: " + e.getMessage());
        }
    }

    //4
    @TempDir
    Path tempDir;
    @Test
    public void getFilesNames_FoundFilesWithExtension() throws IOException {
        Files.createFile(tempDir.resolve("notes.txt"));
        Files.createFile(tempDir.resolve("data.txt"));
        Files.createFile(tempDir.resolve("image.png"));

        List<File> result = Array.getFilesNames(tempDir.toFile(), "txt");

        assertEquals("Найдено 2 файла с расширением .txt",2, result.size());
    }
    /*    @Test
        public void getFilesNamesTest(){
            List<String> filesNames = Array.getFilesNames("D:\\IntelliJ IDEA Community Edition 2024.2.3\\Seventh\\src\\TestDirectory", ".abc");
            System.out.println(filesNames);
        }
        @Test
        public void getFilesNames_FilesWithGivenExtension() throws IOException {
            // Создаем тестовые файлы во временной директории
            File file1 = tempDir.resolve("file1.txt").toFile();
            File file2 = tempDir.resolve("file2.txt").toFile();
            tempDir.resolve("image.png").toFile();  // Файл с другим расширением

            file1.createNewFile();
            file2.createNewFile();

            // тестируемый метод
            List<File> result = Array.getFilesNames(tempDir.toFile(), "txt");  // without point

            assertEquals(2, result.size());
            assertTrue(result.stream().anyMatch(f -> f.getName().equals("file1.txt")));
            assertTrue(result.stream().anyMatch(f -> f.getName().equals("file2.txt")));
        }
    */
    @Test
    public void getFilesNames_NoFilesWithExtension() throws IOException {
        // Создаем тестовые файлы с другими расширениями
        Files.createFile(tempDir.resolve("document.pdf"));
        Files.createFile(tempDir.resolve("data.xlsx"));

        // Вызываем метод с правильными параметрами
        List<File> result = Array.getFilesNames(tempDir.toFile(), "txt"); // Без точки перед расширением

        // Проверяем что список пустой
        assertTrue("Список пуст, нет файлов с расширением .txt",result.isEmpty());
    }
}