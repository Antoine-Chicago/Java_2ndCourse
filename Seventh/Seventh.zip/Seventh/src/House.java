import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public class House implements Serializable {
    private String cadaster, address;
    private Person admin;
    private List<Flat> flats;

    public House(String cadaster, String address, Person admin, List<Flat> list){
        if (cadaster == null || cadaster.isEmpty()){
            throw new IllegalArgumentException("Нет кадастрового");
        }
        this.cadaster = cadaster;

        if (address == null || address.isEmpty()){
            throw new IllegalArgumentException("Нет адреса");
        }
        this.address = address;

        if (admin == null){
            throw new IllegalArgumentException("Нет старшего");
        }
        this.admin = admin;

        //if (flats == null || flats.isEmpty()){
        //    throw new IllegalArgumentException("Нет квартиры");
        //}
        //this.flats = flats;
    }

    public String getCadaster() {return cadaster;}
    public void setCadaster(String cadaster) {this.cadaster = cadaster;}

    public String getAddress() {return address;}
    public void setAddress(String address) {this.address = address;}

    public Person getAdmin() {return admin;}
    public void setAdmin(Person admin) {this.admin = admin;}

    public List<Flat> getFlats() {return flats;}
    public void setFlats(List<Flat> flats) {this.flats = flats;}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        House house = (House) o;
        return Objects.equals(cadaster, house.cadaster) && Objects.equals(address, house.address) && Objects.equals(admin, house.admin) && Objects.equals(flats, house.flats);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cadaster, address, admin, flats);
    }

    @Override
    public String toString() {
        return "House{" +
                "cadaster='" + cadaster + '\'' +
                ", address='" + address + '\'' +
                ", admin=" + admin +
                ", flats=" + flats +
                '}';
    }
}
