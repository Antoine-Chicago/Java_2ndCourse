import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class HouseJsonServiceTest {

    @Test
    public void testSerializeAndDeserializeHouse() throws Exception {

        Person admin = new Person("Сидоров", "Сидор", "Сидорович", 10, 2, 1986);

        List<Person> owners = Arrays.asList(
                new Person("Иванов", "Иван", "Иванович", 28, 3, 1961),
                new Person("Петрова", "Мария", "Сергеевна", 20, 7, 2005)
        );

        List<Flat> flats = Arrays.asList(
                new Flat(1, 50.5, owners),
                new Flat(2, 60.0, owners)
        );

        House originalHouse = new House("12345", "ул. Ленина, 1", admin, flats);

        // 2. Сериализация в JSON
        String json = HouseJsonService.serializeHouse(originalHouse);
        String expectedJson = "{\r\n" +
                "  \"address\" : \"ул. Ленина, 1\",\r\n" +
                "  \"flats\" : [ {\r\n" +
                "    \"number\" : 1,\r\n" +
                "    \"square\" : 50.5,\r\n" +
                "    \"owners\" : [ {\r\n" +
                "      \"surname\" : \"Иванов\",\r\n" +
                "      \"name\" : \"Иван\",\r\n" +
                "      \"father\" : \"Иванович\",\r\n" +
                "      \"day\" : 28,\r\n" +
                "      \"month\" : 3,\r\n" +
                "      \"year\" : 1961\r\n" +
                "    }, {\r\n" +
                "      \"surname\" : \"Петрова\",\r\n" +
                "      \"name\" : \"Мария\",\r\n" +
                "      \"father\" : \"Сергеевна\",\r\n" +
                "      \"day\" : 20,\r\n" +
                "      \"month\" : 7,\r\n" +
                "      \"year\" : 2005\r\n" +
                "    } ]\r\n" +
                "  }, {\r\n" +
                "    \"number\" : 2,\r\n" +
                "    \"square\" : 60.0,\r\n" +
                "    \"owners\" : [ {\r\n" +
                "      \"surname\" : \"Иванов\",\r\n" +
                "      \"name\" : \"Иван\",\r\n" +
                "      \"father\" : \"Иванович\",\r\n" +
                "      \"day\" : 28,\r\n" +
                "      \"month\" : 3,\r\n" +
                "      \"year\" : 1961\r\n" +
                "    }, {\r\n" +
                "      \"surname\" : \"Петрова\",\r\n" +
                "      \"name\" : \"Мария\",\r\n" +
                "      \"father\" : \"Сергеевна\",\r\n" +
                "      \"day\" : 20,\r\n" +
                "      \"month\" : 7,\r\n" +
                "      \"year\" : 2005\r\n" +
                "    } ]\r\n" +
                "  } ],\r\n" +
                "  \"cadaster\" : \"12345\",\r\n" +
                "  \"admin\" : {\r\n" +
                "    \"surname\" : \"Сидоров\",\r\n" +
                "    \"name\" : \"Сидор\",\r\n" +
                "    \"father\" : \"Сидорович\",\r\n" +
                "    \"day\" : 10,\r\n" +
                "    \"month\" : 2,\r\n" +
                "    \"year\" : 1986\r\n" +
                "  }\r\n" +
                "}";
        assertEquals(expectedJson, json);
    }

    @Test
    public void deserializationTest() throws Exception{
        String json = "{\r\n" +
                "  \"address\" : \"ул. Ленина, 1\",\r\n" +
                "  \"flats\" : [ {\r\n" +
                "    \"number\" : 1,\r\n" +
                "    \"square\" : 50.5,\r\n" +
                "    \"owners\" : [ {\r\n" +
                "      \"surname\" : \"Иванов\",\r\n" +
                "      \"name\" : \"Иван\",\r\n" +
                "      \"father\" : \"Иванович\",\r\n" +
                "      \"day\" : 28,\r\n" +
                "      \"month\" : 3,\r\n" +
                "      \"year\" : 1961\r\n" +
                "    }, {\r\n" +
                "      \"surname\" : \"Петрова\",\r\n" +
                "      \"name\" : \"Мария\",\r\n" +
                "      \"father\" : \"Сергеевна\",\r\n" +
                "      \"day\" : 20,\r\n" +
                "      \"month\" : 7,\r\n" +
                "      \"year\" : 2005\r\n" +
                "    } ]\r\n" +
                "  }, {\r\n" +
                "    \"number\" : 2,\r\n" +
                "    \"square\" : 60.0,\r\n" +
                "    \"owners\" : [ {\r\n" +
                "      \"surname\" : \"Иванов\",\r\n" +
                "      \"name\" : \"Иван\",\r\n" +
                "      \"father\" : \"Иванович\",\r\n" +
                "      \"day\" : 28,\r\n" +
                "      \"month\" : 3,\r\n" +
                "      \"year\" : 1961\r\n" +
                "    }, {\r\n" +
                "      \"surname\" : \"Петрова\",\r\n" +
                "      \"name\" : \"Мария\",\r\n" +
                "      \"father\" : \"Сергеевна\",\r\n" +
                "      \"day\" : 20,\r\n" +
                "      \"month\" : 7,\r\n" +
                "      \"year\" : 2005\r\n" +
                "    } ]\r\n" +
                "  } ],\r\n" +
                "  \"cadaster\" : \"12345\",\r\n" +
                "  \"admin\" : {\r\n" +
                "    \"surname\" : \"Сидоров\",\r\n" +
                "    \"name\" : \"Сидор\",\r\n" +
                "    \"father\" : \"Сидорович\",\r\n" +
                "    \"day\" : 10,\r\n" +
                "    \"month\" : 2,\r\n" +
                "    \"year\" : 1986\r\n" +
                "  }\r\n" +
                "}";

        // 3. Десериализация обратно в объект
        House deserializedHouse = HouseJsonService.deserializeHouse(json);

        // 4. Проверки

        assertNotNull(deserializedHouse);
        assertEquals("12345", deserializedHouse.getCadaster());
        assertEquals("ул. Ленина, 1", deserializedHouse.getAddress());
        assertEquals("Сидоров Сидор Сидорович", deserializedHouse.getAdmin().getFullName());
    }
}