import org.junit.Test;
import java.io.*;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.nio.file.Path;
import java.util.List;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.nio.file.Files;

public class ArrayTest {
    @Test
    public void testWriteBinaryStream() throws IOException {
        int[] data = {1, 2, 3};
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        Array.write_BinaryStream(data, baos);// Запись данных

        byte[] resultBytes = baos.toByteArray();

        assertEquals(data.length * Integer.BYTES, resultBytes.length);// Проверяем количество байтов
    }

    @Test
    public void testReadBinaryStream() throws IOException {
        int[] data = {1, 2, 3};

        // Создаем поток с данными для чтения
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);

        // Записываем данные в поток
        for (int num : data) {
            dos.writeInt(num);
        }

        // Создаем входной поток на основе записанных данных
        ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());

        int[] readData = new int[data.length];
        Array.read_BinaryStream(readData, bais); // Считываем числа из потока

        assertArrayEquals(data, readData); // Проверяем, что считанные данные == исходным
    }

    @org.testng.annotations.Test
    public void testWriteCharStream() throws IOException {
        char[] chars = {'A', 'B', 'C'};
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Array.write_CharStream(chars, new OutputStreamWriter(baos));//Запись символы в файл, разделяя пробелами.

        String expectedResult = "A B C ";
        assertEquals(expectedResult, baos.toString("UTF-8"));
    }

    @Test
    public void testReadCharStream() throws IOException {
        char[] chars = {'X', 'Y', 'Z'};
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Array.write_CharStream(chars, new OutputStreamWriter(baos));

        ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
        CharArrayReader car = new CharArrayReader(new String(bais.readAllBytes(), "UTF-8").toCharArray());

        CharArrayWriter actualBuf = Array.read_CharStream(chars, car);//Читает символьный массив

        String expectedContent = "X Y Z ";
        assertEquals(expectedContent, actualBuf.toString());
    }

    @Test
    public void testEmptyArray() throws IOException {

        int[] emptyArr = {};

        ByteArrayOutputStream OutStream = new ByteArrayOutputStream();
        Array.write_BinaryStream(emptyArr, OutStream); // Запись пустой массив

        ByteArrayInputStream InStream = new ByteArrayInputStream(OutStream.toByteArray());

        int[] resultArr = new int[emptyArr.length]; // Массив нулевого размера
        Array.read_BinaryStream(resultArr, InStream); //читает из пустого потока

        assertArrayEquals(emptyArr, resultArr); //получить пустой массив

    }

    @Test
    public void testRandomAccessFile() throws IOException{
        String filePath = "numbers.txt";
        long startPosition = 8;
        int numbersToRead = 3;

        try {
            DataOutputStream dos = new DataOutputStream(new FileOutputStream("numbers.txt"));
            for (int i = 1; i <= 5; i++) {
                dos.writeInt(i); // Записываем числа в бинарном формате
            }
            int[] numbers = Array.readFromPosition(filePath, startPosition, numbersToRead);

            System.out.println("Прочитанные числа:");
            for (int num : numbers) {
                System.out.println(num);
            }

        } catch (IOException e) {
            System.err.println("Ошибка при чтении файла: " + e.getMessage());
        }
    }

    //4
    @Test
    public void testListFilesWithExtension() {
        // Создаем mock-объект File
        File dir = mock(File.class);
        File file1 = mock(File.class);
        File file2 = mock(File.class);
        File file3 = mock(File.class);
        File file4 = mock(File.class);

        // Настраиваем поведение mock-объектов
        when(dir.isDirectory()).thenReturn(true);
        when(dir.listFiles()).thenReturn(new File[]{file1, file2, file3, file4});

        when(file1.isFile()).thenReturn(true);
        when(file1.getName()).thenReturn("papper.txt");

        when(file2.isFile()).thenReturn(true);
        when(file2.getName()).thenReturn("document.pdf");

        when(file3.isFile()).thenReturn(false);
        when(file3.getName()).thenReturn("subdir");

        when(file4.isFile()).thenReturn(true);
        when(file4.getName()).thenReturn("doc1.pdf");

        // Вызываем тестируемый метод
        List<File> result = Array.FileLister.listFilesWithExtension(dir, "pdf");

        // Проверяем результаты
        assertEquals(2, result.size());
    }
    @Test
    public void testListFilesWithOutExtension() {
        // Создаем mock-объект File
        File dir = mock(File.class);
        File file1 = mock(File.class);
        File file2 = mock(File.class);
        File file3 = mock(File.class);
        File file4 = mock(File.class);

        // Настраиваем поведение mock-объектов
        when(dir.isDirectory()).thenReturn(true);
        when(dir.listFiles()).thenReturn(new File[]{file1, file2, file3, file4});

        when(file1.isFile()).thenReturn(true);
        when(file1.getName()).thenReturn("test.txt");

        when(file2.isFile()).thenReturn(true);
        when(file2.getName()).thenReturn("document.pdf");

        when(file3.isFile()).thenReturn(false);
        when(file3.getName()).thenReturn("sayonaraDir");

        when(file4.isFile()).thenReturn(true);
        when(file4.getName()).thenReturn("document1.pdf");

        // Вызываем тестируемый метод
        List<File> result = Array.FileLister.listFilesWithExtension(dir, "zip");

        // Проверяем результаты
        assertEquals(0, result.size());
    }

}