import java.io.*;

public class Serialize {
    // Сериализация объекта House в поток
    public static void serializeHouse(House house, OutputStream outputStream) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(outputStream)) { //outputStream поток для записи сериализованных данных
            oos.writeObject(house);
        }
    }

    // Десериализация объекта House из потока
    public static House deserializeHouse(InputStream inputStream) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(inputStream)) { //inputStream поток для чтения сериализованных данных
            return (House) ois.readObject();
        }
    }
}
