import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.Objects;

class Person implements Serializable{
    private String surname, name, father;
    private int day, month, year;

    @JsonCreator
    public Person(@JsonProperty("surname") String surname,
                  @JsonProperty("name") String name,
                  @JsonProperty("father") String father,
                  @JsonProperty("day") int day,
                  @JsonProperty("month") int month,
                  @JsonProperty("year") int year){
        if(surname== null || surname.isEmpty()){throw new IllegalArgumentException("Нет фамилии");}
        this.surname=surname;

        if(name== null || name.isEmpty()){throw new IllegalArgumentException("Name must be not empty");}
        this.name=name;

        if(father== null || father.isEmpty()){throw new IllegalArgumentException("Fathername must be not empty");}
        this.father=father;

        if(day < 1 || day > 31){throw new IllegalArgumentException("");}
        this.day=day;

        if(month < 1 || month > 12){throw new IllegalArgumentException("");}
        this.month = month;

        if(year < 0){throw new IllegalArgumentException("");}
        this.year = year;
    }

    public String getSurname() {return surname;}
    public void setSurname(String surname) {this.surname = surname;}

    public String getName() {return name;}
    public void setName(String name) {this.name = name;}

    public String getFather() {return father;}
    public void setFather(String father) {this.father = father;}

    public int getDay() {return day;}
    public void setDay(int day) {this.day = day;}

    public int getMonth() {return month;}
    public void setMonth(int month) {this.month = month;}

    public int getYear() {return year;}
    public void setYear(int year) {this.year = year;}

    @JsonIgnore
    public String getFullName() {
        return surname + " " + name + " " + father;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Person person = (Person) o;
        return day == person.day && month == person.month && year == person.year && Objects.equals(surname, person.surname) && Objects.equals(name, person.name) && Objects.equals(father, person.father);
    }

    @Override
    public int hashCode() {
        return Objects.hash(surname, name, father, day, month, year);
    }

    @Override
    public String toString() {
        return "Person{" +
                "surname='" + surname + '\'' +
                ", name='" + name + '\'' +
                ", father='" + father + '\'' +
                ", day=" + day +
                ", month=" + month +
                ", year=" + year +
                '}';
    }
}
