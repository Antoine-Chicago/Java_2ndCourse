import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import java.io.IOException;

public class HouseJsonService {
    private static final ObjectMapper mapper = new ObjectMapper()
            .enable(SerializationFeature.INDENT_OUTPUT);

    public static String serializeHouse(House house) throws IOException {
        return mapper.writeValueAsString(house);
    }

    public static House deserializeHouse(String json) throws IOException {
        return mapper.readValue(json, House.class);
    }
}
