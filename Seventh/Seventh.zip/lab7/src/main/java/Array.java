import java.io.*;
import java.io.RandomAccessFile;
import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class Array {
    public static void write_BinaryStream(int[] arr, OutputStream file) throws IOException {
        DataOutputStream output = new DataOutputStream(file);
        for(int i : arr){
            output.writeInt(i);
        }

        output.close();
    }
    public static int[] read_BinaryStream(int[] arr, InputStream file) throws IOException {
        DataInputStream input = new DataInputStream(file);
        for(int i = 0; i < arr.length; i++){
            arr[i] = input.readInt();
        }
        return arr;
    }
    public static void write_CharStream(char[] arr, Writer file) throws IOException {
        BufferedWriter out = new BufferedWriter(file);
        for(char i : arr){
            out.write(String.valueOf(i));
            out.write(' ');
        }
        out.flush();
    }
    public static CharArrayWriter read_CharStream(char[] arr, Reader file) throws IOException {
        CharArrayWriter buf1 = new CharArrayWriter();
        for (char i : arr){
            buf1.write(i);
            buf1.write(' ');
        }
        return buf1;
    }

    public static int[] readFromPosition(String filename, long position, int count) throws IOException {
        //position начальная позиция
        //count количество чисел для чтения

        int[] result = new int[count];
        try (RandomAccessFile raf = new RandomAccessFile(filename, "r")) {
            raf.seek(position); // Переход на позицию
            for (int i = 0; i < count; i++) {
                result[i] = raf.readInt(); // чтение чисел
            }
        } catch (EOFException e) {
            throw new IOException("Недостаточно данных в файле", e);
        }
        return result;
    }

    public class FileLister {
        public static List<File> listFilesWithExtension(File directory, String extension) {
            //directory - объект File
            //extension-строка с расширением файлов
            List<File> result = new ArrayList<>();
            if (directory == null || !directory.isDirectory()) {
                return result;
            }

            File[] files = directory.listFiles(); //чтение файл
            if (files == null) {
                return result;
            }

            for (File file : files) {
                if (file.isFile() && file.getName().endsWith("." + extension)) {
                    result.add(file);
                }
            }
            return result;
        }
    }
}

