import java.io.Serializable;
import java.util.List;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class House implements Serializable {
    private String cadaster, address;
    private Person admin;
    private List<Flat> flats;


    @JsonCreator
    public House(@JsonProperty("cadastralNumber") String cadaster,
                 @JsonProperty("address") String address,
                 @JsonProperty("senior") Person admin,
                 @JsonProperty("flats") List<Flat> flats) {
        this.cadaster = cadaster;
        this.address = address;
        this.admin = admin;
        this.flats = flats;
    }

    public String getCadaster() { return cadaster; }
    public String getAddress() { return address; }
    public Person getAdmin() { return admin; }
    public List<Flat> getFlats() { return flats; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        House house = (House) o;
        return Objects.equals(cadaster, house.cadaster) && Objects.equals(address, house.address) && Objects.equals(admin, house.admin) && Objects.equals(flats, house.flats);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cadaster, address, admin, flats);
    }

    @Override
    public String toString() {
        return "House{" +
                "cadaster='" + cadaster + '\'' +
                ", address='" + address + '\'' +
                ", admin=" + admin +
                ", flats=" + flats +
                '}';
    }
}
