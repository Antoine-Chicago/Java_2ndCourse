public class Student extends Human{
    private String faculty;
    public Student(String surname, String name, String father, int year, String faculty) {
        super(surname, name, father, year);
        setFaculty(faculty);
    }
    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }
}
