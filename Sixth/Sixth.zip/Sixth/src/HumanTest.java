import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.*;

class HumanTest {
    @Test
    public void TheSameLastName() {
        List<Human> list = new ArrayList<>(List.of(
                new Human( "Petrov","Peter", "Petrovich", 7),
                new Human("Petrov","Alexander",  "Andreevich", 31),
                new Human("Gogol","Victor",  "Sergeevich", 12),
                new Human("Czech","Antoine",  "Pavlovich", 40),
                new Human( "Astra","Danil", "Nicolaevich", 19)
        ));
        assertEquals(ListDemo.theSameSurname(list, new Human("Petrov","Peter",  "Petrovich", 7)),
                List.of(
                        new Human("Petrov","Peter",  "Petrovich", 7),
                        new Human("Petrov","Alexander",  "Andreevich", 31)
                ));
    }
    @Test
    void testNoMatchingSurname() {
        List<Human> list = new ArrayList<>(List.of(
                new Human("Petrov", "Peter", "Petrovich", 7),
                new Human("Shults", "Victor", "Sergeevich", 12),
                new Human("Grigoriev", "Danil", "Pavlovich", 40)
        ));
        Human humanToCompare = new Human("Ivanov", "Ivan", "Ivanovich", 25);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            ListDemo.theSameSurname(list, humanToCompare);
        });
        String expectedMessage = "Нету однофамильцев";

        assertEquals("Нету однофамильцев",exception.getMessage());
    }
    @Test
    //корректно обработка регистра
    void testCaseSensitivity() {
        List<Human> list = new ArrayList<>(List.of(
                new Human("Petrov", "Peter", "Petrovich", 7),
                new Human("petrov", "Alexander", "Andreevich", 31), // проверка на символику
                new Human("Gogol", "Victor", "Sergeevich", 12)
        ));
        Human humanToCompare = new Human("Petrov", "Ivan", "Ivanovich", 25);

        List<Human> result = ListDemo.theSameSurname(list, humanToCompare);

        assertEquals(1, result.size());
    }
    @Test
    //объект Human равен null
    void testNullHuman() {
        List<Human> list = new ArrayList<>(List.of(
                new Human("Petrov", "Peter", "Petrovich", 7),
                new Human("Gogol", "Victor", "Sergeevich", 12)
        ));

        Exception exception = assertThrows(NullPointerException.class, () -> {
            ListDemo.theSameSurname(list, null);
        });

        assertNotNull(exception);
    }
    @Test
    //список равен null
    void testNullList() {
        Human humanToCompare = new Human("Petrov", "Ivan", "Ivanovich", 25);

        Exception exception = assertThrows(NullPointerException.class, () -> {
            ListDemo.theSameSurname(null, humanToCompare);
        });

        assertNotNull(exception);
    }

    @Test
    public void DeleteHuman() {
        List<Human> list = new ArrayList<>(List.of(
                new Human("Petrov", "Peter", "Petrovich", 12),
                new Human("Petrov","Alexander",  "Andreevich", 31),
                new Human("Gogol","Victor",  "Sergeevich", 12),
                new Human("Czech","Antoine",  "Pavlovich", 40),
                new Human( "Astra","Danil", "Nicolaevich", 19)
        ));

        var Per = ListDemo.deleteHuman(list, new Human("Petrov","Peter",  "Petrovich", 12));
        assertEquals(Per,
                List.of(
                        new Human("Petrov","Alexander",  "Andreevich", 31),
                        new Human("Gogol","Victor",  "Sergeevich", 12),
                        new Human("Czech","Antoine",  "Pavlovich", 40),
                        new Human( "Astra","Danil", "Nicolaevich", 19)
                ));


        assertEquals(ListDemo.deleteHuman(list, new Human("Petrov","AAA" , "Petrovich", 12)),
                List.of(
                        new Human("Petrov","Peter",  "Petrovich", 12),
                        new Human("Petrov","Alexander",  "Andreevich", 31),
                        new Human("Gogol","Victor",  "Sergeevich", 12),
                        new Human("Czech","Antoine",  "Pavlovich", 40),
                        new Human( "Astra","Danil", "Nicolaevich", 19)
                ));

    }

    //6.4
    @Test
    void testNoIntersection() {
        List<Set<Integer>> list = new ArrayList<>();
        list.add(new HashSet<>(Set.of(1, 2, 3)));
        list.add(new HashSet<>(Set.of(4, 5, 6)));
        list.add(new HashSet<>(Set.of(7, 8, 9)));

        Set<Integer> set = new HashSet<>(Set.of(10, 11, 12));

        List<Set<Integer>> result = ListDemo.NotIntersect(list, set);

        assertEquals(3, result.size()); // Все множества не пересекаются
    }
    @Test
    void testPartialIntersection() {
        List<Set<Integer>> list = new ArrayList<>();
        list.add(new HashSet<>(Set.of(1, 2, 3)));
        list.add(new HashSet<>(Set.of(4, 5, 6)));
        list.add(new HashSet<>(Set.of(7, 8, 9)));

        Set<Integer> set = new HashSet<>(Set.of(3, 6, 9));

        List<Set<Integer>> result = ListDemo.NotIntersect(list, set);

        assertEquals(0, result.size()); // Все множества пересекаются
    }
    @Test
    void testSomeIntersection() {
        List<Set<Integer>> list = new ArrayList<>();
        list.add(new HashSet<>(Set.of(1, 2, 3)));
        list.add(new HashSet<>(Set.of(4, 5, 6)));
        list.add(new HashSet<>(Set.of(7, 8, 9)));

        Set<Integer> set = new HashSet<>(Set.of(3, 6));

        List<Set<Integer>> result = ListDemo.NotIntersect(list, set);

        assertEquals(1, result.size()); // Только одно множество не пересекается
    }
    @Test
    void testEmptyList() {
        List<Set<Integer>> list = new ArrayList<>();
        Set<Integer> set = new HashSet<>(Set.of(1, 2, 3));

        List<Set<Integer>> result = ListDemo.NotIntersect(list, set);

        assertTrue(result.isEmpty()); // Пустой список на входе
    }
    @Test
    void testEmptySet() {
        List<Set<Integer>> list = new ArrayList<>();
        list.add(new HashSet<>(Set.of(1, 2, 3)));
        list.add(new HashSet<>(Set.of(4, 5, 6)));

        Set<Integer> set = new HashSet<>();

        List<Set<Integer>> result = ListDemo.NotIntersect(list, set);

        assertEquals(2, result.size()); // Пустое множество на входе

    }
    //6,5
    @Test //пустой список
    void testListMaxAgeWithEmptyList() {
        List<Human> emptyList = Collections.emptyList();
        Set<Human> result = ListDemo.listMaxAge(emptyList);
        assertTrue(result.isEmpty());
    }
    @Test //список с одним человеком
    void testListMaxAgeWithSingleHuman() {
        List<Human> list = Collections.singletonList(new Human("Barvashin","John", "Kirillovich",30));
        Set<Human> result = ListDemo.listMaxAge(list);
        assertEquals(1, result.size());
        assertTrue(result.contains(new Human("Barvashin","John", "Kirillovich", 30)));
    }
    @Test //несколько человек с одинаковым максимальным возрастом
    void testListMaxAgeWithMultipleHumansSameAge() {
        List<Human> list = Arrays.asList(
                new Human("Fisher","Alice", "Artemovna",25),
                new Human("Terentiev","Bob", "Renatovich",25),
                new Human("Lorak","Anna", "Alekseevna", 25)
        );
        Set<Human> result = ListDemo.listMaxAge(list);
        assertEquals(3, result.size());
        assertTrue(result.containsAll(list));
    }
    @Test //разные возраста с несколькими самыми старшими
    void testListMaxAgeWithDifferentAges() {
        Human oldest1 = new Human("Oldest1", "Peter","Grigorievich",40);
        Human oldest2 = new Human("Oldest2", "Victor", "Sergeevich",40);
        List<Human> list = Arrays.asList(
                new Human("Young1", "Kostya","Dmitriy",20),
                new Human("Young2", "Danchik","Nicola",25),
                oldest1,
                oldest2,
                new Human("Middle", "Sergey","Pavlovich",35)
        );
        Set<Human> result = ListDemo.listMaxAge(list);
        assertEquals(2, result.size());
        assertTrue(result.contains(oldest1));
        assertTrue(result.contains(oldest2));
    }
    @Test //один самый старший
    void testListMaxAgeWithOneOldest() {
        Human oldest = new Human("Oldest", "Danil","Andreevich",99);
        List<Human> list = Arrays.asList(
                new Human("Young", "Ilya","",20),
                new Human("Middle","Sergey","Pavlovich", 50),
                oldest
        );
        Set<Human> result = ListDemo.listMaxAge(list);
        assertEquals(1, result.size());
        assertTrue(result.contains(oldest));
    }

    //6.7
    @Test
    void testEmptyMapAndSet() {
        Map<Integer, Human> map = new HashMap<>();
        Set<Integer> keys = new HashSet<>();
        Set<Human> expectedResult = new HashSet<>();
        assertEquals(expectedResult, ListDemo.selectSomeFromMap(map, keys), "Return an empty set");
    }
    @Test
    void testNonEmptyMapWithNoMatchingKeys() {
        Map<Integer, Human> map = new HashMap<>();
        map.put(1, new Human("Ivanov", "Ivan", "Petrovich", 1990));
        map.put(2, new Human("Smirnov", "Sergey", "Vasilyevich", 1985));
        Set<Integer> keys = new HashSet<>();
        keys.add(3); // Нет такого индификатора
        keys.add(4);
        Set<Human> expectedResult = new HashSet<>();
        assertEquals(expectedResult, ListDemo.selectSomeFromMap(map, keys), "Нет подходящих индификаторов");
    }

    @Test
    void testNonEmptyMapWithMatchingKeys() {
        Map<Integer, Human> map = new HashMap<>();
        map.put(1, new Human("Ivanov", "Maxim", "Petrovich", 1990));
        map.put(2, new Human("Smirnov", "Alexander", "Vasilyevich", 1951));
        map.put(3, new Human("Larionov", "Sergey", "Pavlovich", 2005));
        Set<Integer> keys = new HashSet<>();
        keys.add(1); // Есть такой индификатор в карте
        keys.add(2);
        keys.add(3);
        Set<Human> expectedResult = new HashSet<>();
        expectedResult.add(new Human("Ivanov", "Maxim", "Petrovich", 1990));
        expectedResult.add(new Human("Smirnov", "Alexander", "Vasilyevich", 1951));
        expectedResult.add(new Human("Larionov", "Sergey", "Pavlovich", 2005));
        assertEquals(expectedResult, ListDemo.selectSomeFromMap(map, keys), "Все индификаторы соответствуют");
    }

    @Test
    void testMixedKeys() {
        Map<Integer, Human> map = new HashMap<>();
        map.put(1, new Human("Ivanov", "Ivan", "Petrovich", 1980));
        map.put(2, new Human("Smirnov", "Sergey", "Vasilyevich", 1985));
        Set<Integer> keys = new HashSet<>();
        keys.add(1); // Есть ключ в карте
        keys.add(9); // Нет ключа в карте
        Set<Human> expectedResult = new HashSet<>();
        expectedResult.add(new Human("Ivanov", "Ivan", "Petrovich", 1980));
        assertEquals(expectedResult, ListDemo.selectSomeFromMap(map, keys), "Возвращен только 1 соответ. индификатор");
    }
    //6.8
    @Test
    void testEmptyMapReturnsEmptyList() {
        Map<Integer, Human> emptyMap = new HashMap<>();
        List<Integer> expectedResult = Collections.emptyList();
        List<Integer> actualResult = ListDemo.idAgeEighteen(emptyMap);
        assertEquals(expectedResult, actualResult);
    }

    @Test
    void testAllAdults() {
        Map<Integer, Human> map = new HashMap<>();
        map.put(101, new Human("Kudrik","Alice", "Artemovna",25));
        map.put(102, new Human("Shishkin","Bob", "Igorevich",30));
        map.put(103, new Human("Arkashev","Kostya","Dmitirich", 35));

        List<Integer> expectedResult = Arrays.asList(101, 102, 103);
        List<Integer> actualResult = ListDemo.idAgeEighteen(map);
        assertEquals(expectedResult, actualResult);
    }

    @Test
    void testNoAdults() {
        Map<Integer, Human> map = new HashMap<>();
        map.put(201, new Human("Schnaider","David","Sergeevich", 15));
        map.put(202, new Human("Scott","Emily", "",17));
        map.put(203, new Human("Ruzvelt","Frank", "Genrivich",16));

        List<Integer> expectedResult = Collections.emptyList();
        List<Integer> actualResult = ListDemo.idAgeEighteen(map);
        assertEquals(expectedResult, actualResult,"Всем меньше 18");
    }

    @Test
    void testMixedAges() {
        Map<Integer, Human> map = new HashMap<>();
        map.put(301, new Human("Washington","George", "Conor",36));
        map.put(302, new Human("Shlegel","Helen", "Vladimirovna",10));
        map.put(303, new Human("Ivanov","Ivan" ,"",17));
        map.put(304, new Human("Jack","Rassel","Terier", 52));

        List<Integer> expectedResult = Arrays.asList(304, 301);
        List<Integer> actualResult = ListDemo.idAgeEighteen(map);
        assertEquals(expectedResult, actualResult);
    }
    //6.9
    @Test
    void testKeyAgeWithEmptyMap() {
        Map<Integer, Human> input = new HashMap<>();
        Map<Integer, Integer> expected = new HashMap<>();

        Map<Integer, Integer> result = ListDemo.keyAge(input);

        assertEquals(expected, result);
    }

    @Test
    void testKeyAgeWithSingleEntry() {
        Map<Integer, Human> input = new HashMap<>();
        input.put(1, new Human("Kudrik","Alice", "Artemovna",1990));

        Map<Integer, Integer> expected = new HashMap<>();
        expected.put(1, 1990);

        Map<Integer, Integer> result = ListDemo.keyAge(input);

        assertEquals(expected, result);
    }

    @Test
    void testKeyAgeWithMultipleEntries() {
        Map<Integer, Human> input = new HashMap<>();
        input.put(1, new Human("Kudrik","Alice", "Artemovna",1990));
        input.put(2, new Human("Smirnov", "Sergey", "Vasilyevich",1985));
        input.put(3, new Human("Arkashev","Kostya","Dmitrievich",2000));

        Map<Integer, Integer> expected = new HashMap<>();
        expected.put(1, 1990);
        expected.put(2, 1985);
        expected.put(3, 2000);

        Map<Integer, Integer> result = ListDemo.keyAge(input);

        assertEquals(expected, result);
    }

    //6,10
    @Test
    void testListAgeHuman_WithMatchingYear() {

        Human person1 = new Human("Doe", "John", "Michael", 1990);
        Human person2 = new Human("Smith", "Jane", "Robert", 1987);
        Human person3 = new Human("Brown", "Alice", "David", 1990);
        Set<Human> humans = new HashSet<>(Arrays.asList(person1, person2, person3));

        int targetYear = 1990;

        Map<Integer, List<Human>> result = ListDemo.listAgeHuman(humans, targetYear);

        assertEquals(1, result.size());
        assertTrue(result.containsKey(targetYear));

        List<Human> people = result.get(targetYear);
        assertEquals(2, people.size());
    }

    @Test
    void testListAgeHuman_WithNoMatchingYear() {

        Set<Human> humans = new HashSet<>();
        humans.add(new Human("Smith", "Jane", "Robert", 1987));
        humans.add(new Human("Bobrov","Vanilin","Saharovich", 1995));
        int targetYear = 2000;

        Map<Integer, List<Human>> result = ListDemo.listAgeHuman(humans, targetYear);

        assertEquals(1, result.size());
        assertTrue(result.containsKey(targetYear));
        assertTrue(result.get(targetYear).isEmpty());
    }

    @Test
    void testListAgeHuman_WithEmptySet() {
        Set<Human> humans = new HashSet<>();
        int targetYear = 1990;

        Map<Integer, List<Human>> result = ListDemo.listAgeHuman(humans, targetYear);

        assertEquals(1, result.size());
        assertTrue(result.containsKey(targetYear));
        assertTrue(result.get(targetYear).isEmpty());
    }

    @Test
    void testListAgeHuman_WithMultipleYearsButOnlyOneTarget() {
        // Arrange
        Set<Human> humans = new HashSet<>();
        humans.add(new Human("Kudrik","Alice", "Artemovna",1980));
        humans.add(new Human("Shlegel","Helen", "Vladimirovna", 1995));
        humans.add(new Human("Chaplin","Charlie","", 2003));

        int targetYear = 1995;

        Map<Integer, List<Human>> result = ListDemo.listAgeHuman(humans, targetYear);

        assertEquals(1, result.size());
        assertTrue(result.containsKey(targetYear));

        List<Human> people = result.get(targetYear);
        assertEquals(1, people.size());

    }

    @Test
    public void testListage(){
        Set<Human> hum1 = new HashSet<>();
        hum1.add(new Student("Prudova","Victoria","Sergeevna",20,"FCTK"));
        hum1.add(new Human("Iljev","Victor","Peterovich",67));
        hum1.add(new Human("Gogol","Nicolay","Vasilievich",38));
        hum1.add(new Student("Abricosov","Valentin","Leonidich",20,"FEPМ"));
        hum1.add(new Human("Danisimo","Florencia","",15));
        Map<Integer,List<Human>> map1 = ListDemo.listAgeHuman(hum1,20);

        System.out.println(map1.toString());
    }

}