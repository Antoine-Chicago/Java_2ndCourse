import java.util.Collection;
import java.util.List;
import java.util.*;
import java.util.Objects;

public class Human {
    private String surname, name, father;
    private int year;

    public Human(String surname, String name, String father, int year){
        setSurname(surname);
        setName(name);
        setFather(father);
        setYear(year);
    }

    public String getSurname() {return surname;}

    public String getName() {return name;}

    public String getFather() {return father;}

    public int getYear() {return year;}

    public void setSurname(String surname) {this.surname = surname;}

    public void setName(String name) {this.name = name;}

    public void setFather(String father) {this.father = father;}

    public void setYear(int year) { if (year <= 0) throw new IllegalArgumentException("Year <= 0\n"); this.year = year;}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Human human = (Human) o;
        return year == human.year && Objects.equals(surname, human.surname) && Objects.equals(name, human.name) && Objects.equals(father, human.father);
    }

    @Override
    public int hashCode() {
        return Objects.hash(surname, name, father, year);
    }

    @Override
    public String toString() {
        return "Human{" +
                "surname='" + surname + '\'' +
                ", name='" + name + '\'' +
                ", father='" + father + '\'' +
                ", year=" + year +
                '}';
    }
}
class ListDemo{
    public static List<Human> theSameSurname(List<Human> humans, Human human) {
        List<Human> temp = new ArrayList<>();
        for (Human i : humans) {
            if (i.getSurname().equals(human.getSurname())) {
                temp.add(i);
            }

        }
        if (temp.isEmpty()) {
            throw new IllegalArgumentException("Нету однофамильцев");
        }
        return temp;
    }

    public static List<Human> deleteHuman(List<Human> people, Human human) {
        List<Human> temp = new ArrayList<>();
        for (Human i : people) {
            if (!i.equals(human)) {
                temp.add(new Human(i.getSurname(), i.getName(), i.getFather(), i.getYear()));
            }
        }
        return temp;
    }

    public static List<Set<Integer>> NotIntersect(List<Set<Integer>> list, Set<Integer> set) {
        List<Set<Integer>> temp = new ArrayList<>();
        for (Set<Integer> var : list) {
            boolean f = false;
            for(int i : var){
                f = set.contains(i); //проверка set и мн-ва из списка на пересечение
            }
            if(!f) temp.add(var);
        }
        return temp; //кол-во не пересекающих мн-в
    }

    public static Set<Human> listMaxAge(List<Human> list) {
        int maxAge = 0;
        Set<Human> setMaxAge = new HashSet<Human>();
        for (Human human : list) {
            if (human.getYear() > maxAge) {
                maxAge = human.getYear();
            }
        }
        for (Human human : list) {
            if (human.getYear() == maxAge) {
                setMaxAge.add(human);
            }
        }
        return setMaxAge;
    }

    public static Set<Human> selectSomeFromMap(Map<Integer, Human> map, Set<Integer> set) {
        Set<Human> temp = new HashSet<>();
        for (int i : set) {
            if (map.containsKey(i)) { //проверка на совпадение
                temp.add(map.get(i));
            }
        }
        return temp;
    }

    public static List<Integer> idAgeEighteen(Map<Integer, Human> map) {
        List<Integer> temp = new ArrayList<>();
        for (Map.Entry<Integer, Human> i : map.entrySet()) { //вложенный интерфейс
            if (i.getValue().getYear() >= 18) { //получен значение(возраст) по ключу
                temp.add(i.getKey());
            }
        }
        return temp;
    }

    public static Map<Integer, Integer> keyAge(Map<Integer, Human> map) {
        Map<Integer, Integer> temp = new HashMap<>();
        for (Map.Entry<Integer, Human> i : map.entrySet()) {
            temp.put(i.getKey(), i.getValue().getYear()); //ключ key соответствует значение value.
        }
        return temp;
    }

    public static Map<Integer, List<Human>> listAgeHuman(Set<Human> humans, Integer year) {
        Map<Integer, List<Human>> ageHuman = new HashMap<>();
        List<Human> list1 = new ArrayList<>();
        for (Human human : humans) {
            //List<Human> people = new ArrayList<>();
            if (human.getYear() == year) {
                list1.add(human);
            }

        }
        ageHuman.put(year, list1); //ключу соответствует значение
        return ageHuman;
    }
};