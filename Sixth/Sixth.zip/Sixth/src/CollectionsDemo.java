import java.util.Collection;
import java.util.List;

public class CollectionsDemo {
    public int Search(List<String> list, char c){
        int count = 0;
        if (list == null) {
            throw new IllegalArgumentException("List is null");
        }
        if (list.isEmpty()) {
            throw new IllegalArgumentException("List is EMPTY");
        }
        for (String i: list){
            if (i!=null && !i.isEmpty() && i.charAt(0)==c) {count ++;}
        }
        return count;
    };

}