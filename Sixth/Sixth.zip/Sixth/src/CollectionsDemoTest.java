/*import org.junit.Test;
import static org.junit.Assert.*;

import java.util.Collection;
import java.util.ArrayList;
import java.util.List;



public class CollectionsDemoTest {
    @Test
    public void strings() {
        List<String> list1 = List.of("", "aaa", "bbb", "ccc", "ddd", "abc", "AAA");
        assertEquals(2,strings(list1, 'a'));
    }
}*/
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

class CollectionsDemoTest {

    @Test
    void testSearchWithValidInput() {
        CollectionsDemo demo = new CollectionsDemo();
        List<String> list = Arrays.asList("apple", "banana", "apricot", "cherry", "avocado");
        char c = 'a';
        int result = demo.Search(list, c);
        assertEquals(3, result);
    }

    @Test
    void testSearchWithNoMatches() {
        CollectionsDemo demo = new CollectionsDemo();
        List<String> list = Arrays.asList("banana", "cherry", "date");
        char c = 'a';
        int result = demo.Search(list, c);
        assertEquals(0, result);
    }

    @Test
    void testSearchWithEmptyList() {
        CollectionsDemo demo = new CollectionsDemo();
        List<String> list = Collections.emptyList();
        char c = 'a';
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            demo.Search(list, c);
        });
        assertEquals("List is EMPTY", exception.getMessage(), "List is EMPTY");
    }

    @Test
    void testSearchWithNullList() {
        CollectionsDemo demo = new CollectionsDemo();
        List<String> list = null;
        char c = 'Z';
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            demo.Search(list, c);
        });
        assertEquals("List is null", exception.getMessage(), "List is null");
    }

    @Test
    void testSearchWithNullElements() {
        CollectionsDemo demo = new CollectionsDemo();
        List<String> list = Arrays.asList("chanel", null, null, "cross");
        char c = 'c';
        int result = demo.Search(list, c);
        assertEquals(2, result, "Should count 2 words starting with 'a' ignoring nulls");
    }

    @Test
    void testSearchWithEmptyStrings() {
        CollectionsDemo demo = new CollectionsDemo();
        List<String> list = Arrays.asList("", "jump", "", "jeans");
        char c = 'j';
        int result = demo.Search(list, c);
        assertEquals(2, result, "Should count 2 words starting with 'a' ignoring empty strings");
    }
}