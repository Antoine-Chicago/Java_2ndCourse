import org.example.StringProcessor;
import org.junit.Test;
import static org.junit.Assert.*;

public class PaymentTest {

    // Тест для конструктора и методов получения/установки значений класса Payment
    @Test
    public void testPayment() {
        Payment payment = new Payment("Ashaev Igor Victoroviich", 15, 5, 2023, 12345);

        assertEquals("Ashaev Igor Victoroviich", payment.getName());
        assertEquals(15, payment.getDate());
        assertEquals(5, payment.getMonth());
        assertEquals(2023, payment.getYear());
        assertEquals(12345, payment.getSum());

        payment.setName("Пупкин Вася");
        payment.setDate(20);
        payment.setMonth(6);
        payment.setYear(2024);
        payment.setSum(54321);

        assertEquals("Пупкин Вася", payment.getName());
        assertEquals(20, payment.getDate());
        assertEquals(6, payment.getMonth());
        assertEquals(2024, payment.getYear());
        assertEquals(54321, payment.getSum());
    }

    // Тест для метода equals, проверяющий сравнение объектов Payment
    @Test
    public void testEquals() {
        Payment p1 = new Payment("Ashaev Igor Victoroviich", 15, 5, 2023, 12345);
        Payment p2 = new Payment("Ashaev Igor Victoroviich", 15, 5, 2023, 12345);
        Payment p3 = new Payment("Пупкин Вася", 20, 6, 2024, 54321);
        Payment p4 = new Payment("John Doe", 20, 5, 2023, 12345);
        Payment p5 = new Payment("John Doe", 15, 6, 2023, 12345);
        Payment p6 = new Payment("Larionov Sergey Pavlovich", 27, 4, 2024, 30450);
        Payment p7 = new Payment("Zhuravleff Antoine", 27, 1, 2020, 80000);

        assertEquals(p1, p2);
        assertNotEquals(p1, p3);
        assertNotEquals(p1, p4);
        assertNotEquals(p1, p5);
        assertNotEquals(p1, p6);
        assertNotEquals(p1, p7);
    }

    // Тест для метода hashCode, проверяющий корректность вычисления хэш-кода
    @Test
    public void testHashCode() {
        Payment p1 = new Payment("Quentin Tarantino", 15, 5, 2023, 12345);
        Payment p2 = new Payment("Quentin Tarantino", 15, 5, 2023, 12345);
        Payment p3 = new Payment("Jane Tarantino", 15, 5, 2023, 12345);

        assertEquals(p1.hashCode(), p2.hashCode());
        assertNotEquals(p1.hashCode(), p3.hashCode());
    }

    // Тест для метода toString, проверяющий корректность строкового представления объекта Payment
    @Test
    public void testToString() {
        Payment payment = new Payment("Larionov Sergey Pavlovich", 27, 4, 2024, 30450);
        assertEquals("Larionov Sergey Pavlovich 27 4 2024 30450", payment.toString());
    }
    @Test//(expectedExceptions = IllegalArgumentException.class)
    public void testSumInvalid() {
        Payment paySUM = new Payment("name", 27, 11, 2024,-420);
        assertEquals(-420,paySUM.getSum());

    }

}