import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class FinanceReportTest {

    // Тест для конструктора и методов получения/установки значений класса FinanceReport
    @Test
    void testFinanceReport() {
        FinanceReport report = new FinanceReport("Ashaev Igor Victorovich", 1, 5, 2023);

        Assertions.assertEquals("Ashaev Igor Victorovich", report.getName());
        Assertions.assertEquals(1, report.getDate());
        Assertions.assertEquals(5,report.getMonth());
        Assertions.assertEquals(2023,report.getYear());
        Assertions.assertEquals(0, report.getSize());

        Payment p1 = new Payment("Alice Smith", 10, 5, 2023, 1000);
        Payment p2 = new Payment("Mark Ryder", 15, 8, 2023, 2000);
        Payment p3 = new Payment("Charlie Brown", 20, 5, 2023, 3000);

        report.setPayment(0, p1);
        report.setPayment(1, p2);
        report.setPayment(2, p3);

        Assertions.assertEquals(3, report.getSize());
        Assertions.assertEquals(p1, report.getPayment(0));
        Assertions.assertEquals(p2, report.getPayment(1));
        Assertions.assertEquals(p3, report.getPayment(2));
    }

    // Тест для метода copyPayments, проверяющий корректность создания копии отчета
    @Test //проверка изменения табл. до копирования, и после
    void testCopyPayments() {
        FinanceReport report = new FinanceReport("Ashaev Igor Victorovich", 1, 5, 2023);

        Payment p1 = new Payment("Alice Smith", 10, 5, 2023, 1000);
        Payment p2 = new Payment("Sasha Islankin", 31, 8, 2024, 5000);
        Payment p3 = new Payment("Charlie Brown", 20, 5, 2023, 3000);

        report.setPayment(0, p1);
        report.setPayment(1, p2);
        report.setPayment(2, p3);

        FinanceReport copy = new FinanceReport(report);
        for (int i = 0; i < report.getSize(); i++) {
            Assertions.assertEquals(report.getPayment(i), copy.getPayment(i));
        }

        Payment p4 = new Payment("Physic Pavel Sharapov", 13, 1, 2024, 4200);
        report.setPayment(3, p4);

        Assertions.assertEquals(report.getName(), copy.getName());
        Assertions.assertEquals(report.getDate(), copy.getDate());
        Assertions.assertNotEquals(report.getSize(), copy.getSize());


    }

    // Тест для метода toString, проверяющий корректность строкового представления отчета
    @Test
    void testToString() {
        FinanceReport report = new FinanceReport("Antoine Zhuravleff", 1, 12, 2024);

        Payment p1 = new Payment("Alice Smith", 13, 5, 2023, 100000);
        Payment p2 = new Payment("Miron Moskalenko", 25, 10, 2024, 290000);
        Payment p3 = new Payment("Charlie Brown", 20, 8, 2023, 300000);
        Payment p4 = new Payment("Slawa Markoff", 10, 10, 2024, 550000);

        report.setPayment(0, p1);
        report.setPayment(1, p2);
        report.setPayment(2, p3);
        report.setPayment(3, p4);

        String expected = "[Автор: Antoine Zhuravleff, дата: 1.12.2024, Платежи: [\n" +
                "\tПлательщик: Alice Smith, дата: 13.5.2023 сумма: 1000 руб. 0 коп.\n" +
                "\tПлательщик: Miron Moskalenko, дата: 25.10.2024 сумма: 2900 руб. 0 коп.\n" +
                "\tПлательщик: Charlie Brown, дата: 20.8.2023 сумма: 3000 руб. 0 коп.\n" +
                "\tПлательщик: Slawa Markoff, дата: 10.10.2024 сумма: 5500 руб. 0 коп.\n" +
                "]";

        Assertions.assertEquals(expected, report.toString());
    }

}