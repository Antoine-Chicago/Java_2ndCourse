
package org.example;
import static org.junit.Assert.*;


public class StringProcessorTest {


    public void replay() {
        int n = 0;
        String s = "";
        String s1 = StringProcessor.replay("Magic",2);
        assertEquals("MagicMagic",s1);
    }
    @org.junit.Test
    public void replayNull(){
        int n = 0;
        String s = "";
        String s1 = StringProcessor.replay("MatFak",0);
        assertEquals("",s1);
    }
    @org.junit.Test
    public void replayNeg(){
        //String s1 = StringProcessor.replay("Mama",-1);
        try {
            StringProcessor.replay("vvv",-3);
        } catch (IllegalArgumentException n){
            System.err.println("Length error");
        }
    }
    @org.junit.Test
    public void contains_v1(){
        int n = StringProcessor.contains("abab","a");
        assertEquals(2,n);
    }
    @org.junit.Test
    public void contains_v2(){
        int n = StringProcessor.contains("accbcbcbacbcbac","bc");
        assertEquals(3,n);
    }
    @org.junit.Test
    public void contains_v3(){
        int n = StringProcessor.contains("accbcbcbacbcbac","cbc");
        assertEquals(3,n);
    }

    @org.junit.Test
    //public void newString() {}
    public void newString(){
        String s1 = StringProcessor.newString("s1.3k");
        assertEquals("sодин.триk",s1);
    }

    @org.junit.Test
    public void newString_2(){
        String s1 = StringProcessor.newString("just");
        assertEquals("just",s1);
    }

    @org.junit.Test
    public void newString_3(){
        String s1 = StringProcessor.newString("");
        assertEquals("",s1);
    }

    @org.junit.Test
    public void redactStringBuilder_v1(){
        StringBuilder s1 = StringProcessor.redact("just");
        assertEquals("js",s1.toString());
    }

    @org.junit.Test
    public void redactStringBuilder_v2(){
        StringBuilder s1 = StringProcessor.redact("");
        assertEquals("",s1.toString());
    }

    @org.junit.Test
    public void redactStringBuilder_v3(){
        StringBuilder s1 = StringProcessor.redact("dfghh67ghgh");
        assertEquals("dgh7hh",s1.toString());
    }

    @org.junit.Test
    public void main() {
    }
}

