package org.example;

/*import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str1 = new String();
        String str2 = new String();
        int N;
        str1=("Mummi-troll");
        str2=("");
        System.out.print("Введите N: ");
        N = in.nextInt();

        if (str1 == null) throw new IllegalArgumentException("Строка пуста");
        if (N < 0) throw new ArithmeticException("N < 0");
        if(N == 0){
            System.err.println(str2);
        }

        else {
            for(int i=0; i<N; i++)
                System.out.print(str1);
        }
    }
}*/
public class StringProcessor {
    public static String replay(String str, int n) {
        if (str == null) throw new IllegalArgumentException("Строка пуста");
        if (n < 0) throw new IllegalArgumentException("n < 0");
        if (n == 0) return "";

        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < n; i++) stringBuilder.append(str);

        return stringBuilder.toString();
    }

    public static int contains(String str1, String str2) {
        if (str1 == null || str2 == null || str2.isEmpty()) throw new IllegalArgumentException("Строка пуста");
        if (str1.length() < str2.length()) throw new IllegalArgumentException("Length error");

        int res = 0;

        for (int i = 0; i <= str1.length() - str2.length(); i++) {
            if (str2.equals(str1.subSequence(i, str2.length() + i).toString())) res++;
        }

        return res;
    }

    public static String newString(String str) {
        if (str == null) throw new IllegalArgumentException("Строка пуста");
        if (str.isEmpty()) return "";

        str = str.replaceAll("1", "один");
        str = str.replaceAll("2", "два");
        str = str.replaceAll("3", "три");

        return str;
    }

    public static StringBuilder redact(String s) {
        StringBuilder s1 = new StringBuilder(s);
        if (s1 == null || s1.length() < 2);

        //int size = ;

        for (int i = 1; i < s1.length(); i++) {
            s1.deleteCharAt(i);
        }
        return  s1;
    }

    public static void main(String[] args) {
        System.out.println(replay("Mummi-troll", 2));
        System.out.println(contains("abcadababababab", "b"));
        System.out.println(newString("this is 351.19 \nthis is 212\nthis is 3"));
        //StringBuilder StringBuilder = new StringBuilder("");
        String s1 = new String("abcd78");
        StringBuilder s2 = StringProcessor.redact(s1);
        System.out.println(s2);
    }
}