import java.util.Objects;
import java.util.Scanner;
/*public class Payment {
    private GregorianCalendar date;
    private String name;
    private double sum;

    public Payment(String name, double sum, GregorianCalendar date){
        this.date=date;
        set_Name(name);
        set_Sum(sum);
    }
    public String get_Name(){
        return name;
    }
    public void set_Name(String name){
        if (name == null) throw new IllegalArgumentException("Name must be not null!");
        this.name = name;
    }
    public double get_Sum(){
        return sum;
    }
    public void set_Sum(double sum){
        if (sum <= 0) throw new IllegalArgumentException("Negative sum!");
        this.sum = sum;
    }
    public GregorianCalendar get_Date(){
        return date;
    }

    @Override
    public String toString() {
        return String.format("%nПлательщик: %s Дата: %sn Сумма: %f", name, date.getTime(), sum);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Payment payment = (Payment) o;
        return Double.compare(sum, payment.sum) == 0 && Objects.equals(date, payment.date) && Objects.equals(name, payment.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(date, name, sum);
    }
    public static void main(String[] args) {


    }
}*/
public class Payment {
    private String name;
    private int date;
    private int month;
    private int year;
    private int sum;
    private int payment;

    public Payment(String name, int date, int month, int year, int sum) {
        this.name = name;
        this.date = date;
        this.month = month;
        this.year = year;
        this.sum = sum;
    }

    public String getName() {
        return name;
    }

    public int getDate() {
        return date;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }

    public int getSum() {
        return sum;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDate(int date) {
        this.date = date;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setSum(int sum) {
        this.sum = sum;
    }

    public int getPayment() {
        return payment;
    }
    public void setPayment(int payment) {
        this.payment = payment;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Payment payment)) return false;
        return getDate() == payment.getDate() && getMonth() == payment.getMonth() && getYear() == payment.getYear() && getSum() == payment.getSum() && getName().equals(payment.getName());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getName(), getDate(), getMonth(), getYear(), getSum());
    }

    @Override
    public String toString() {
        return name + " " + date + " " + month + " " + year + " " + sum;
    }
}
