import java.lang.reflect.Method;
import java.util.*;

public class ReflectionDemo {
    public static int countHumans(List<?> objects) { // принимает список объектов
        int count = 0;
        for (Object obj : objects) {
            if (obj instanceof Human) {
                count++;
            } //проверка через оператор
        }
        return count; // элементы Human и подкласс Student
    }


    public static List<String> getPublicMethodNames(Object obj) { // принимает объект и возвращает список имен его методов
        List<String> methodNames = new ArrayList<>();

        if (obj == null) {return methodNames;}

        Class<?> clazz = obj.getClass(); // Получение класс объекта

        Method[] methods = clazz.getMethods();// Получаем все открытые методы

        for (Method method : methods) { methodNames.add(method.getName());} // Сбор в список

        return methodNames;
    }

    public static List<String> getSuperClassNames(Object obj) {
        List<String> superclassNames = new ArrayList<>();
        Class<?> currentClass = obj.getClass();

        while (currentClass != null) {
            superclassNames.add(currentClass.getName());
            currentClass = currentClass.getSuperclass();
        }

        return superclassNames;
    }
}
class Human {
    private String surname;
    private String name;
    private String father;
    private int year;

    public Human(String surname, String name, String father, int year) {
        setSurname(surname);
        setName(name);
        setFather(father);
        setYear(year);
    }

    // Геттеры и сеттеры
    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFather() {
        return father;
    }

    public void setFather(String father) {
        this.father = father;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}

class Student extends Human {
    private String faculty;

    public Student(String surname, String name, String father, int year, String faculty) {
        super(surname, name, father, year);
        setFaculty(faculty);
    }

    // Геттер и сеттер для faculty
    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }
}

class Magistrant extends Student {
    public Magistrant(String surname, String name, String father, int year, String faculty) {
        super(surname, name, father, year, faculty);
    }
}
