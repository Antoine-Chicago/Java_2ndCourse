import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class ReflectionDemoTest {

    @Test
    void testCountHumansWithEmptyList() {
        List<Object> emptyList = List.of();
        int result = ReflectionDemo.countHumans(emptyList);
        assertEquals(0, result);
    }

    @Test
    void testCountHumansWithOnlyHumans() {
        Human human1 = new Human("Иванов", "Иван", "Иванович", 1980);
        Human human2 = new Human("Петров", "Петр", "Петрович", 1975);
        List<Object> humans = Arrays.asList(human1, human2);

        int result = ReflectionDemo.countHumans(humans);
        assertEquals(2, result);
    }

    @Test
    void testCountHumansWithStudents() {
        Student student1 = new Student("Сидоров", "Алексей", "Николаевич", 2000, "ФЦТК");
        Student student2 = new Student("Кузнецова", "Мария", "Сергеевна", 2001, "ФизФак");
        List<Object> students = Arrays.asList(student1, student2);

        int result = ReflectionDemo.countHumans(students);
        assertEquals(2, result); // Student наследуется от Human
    }

    @Test
    void testCountHumansWithHuman_Students_Magister(){
        Human man_1 = new Human("Ашаев", "Игорь", "Викторович", 1971);
        Human woman_1 = new Human("Кудрик", "Алиса", "Артемовна", 2005);
        Student stud_1 = new Student("Сидоров", "Алексей", "Николаевич", 2000, "ФЦТК");
        Student stud_2 = new Student("Кузнецова", "Мария", "Сергеевна", 2004, "ФизФак");
        Magistrant mag = new Magistrant("Oblomov","Miron","",1998,"IMIT");
        List<Object> people = Arrays.asList(man_1, woman_1, stud_1, stud_2, mag);
        int result = ReflectionDemo.countHumans(people);
        assertEquals(5, result); // Magistrant наследуется от Student
    }

    @Test
    void testCountHumansWithMixedObjects() {
        Human human = new Human("Пятин", "Александр", "Васильевич", 1951);
        Student student = new Student("Никитин", "Петр", "", 2000, "ФЭПМ");

        String notHuman = "Это строка, не class Human";
        Integer number = -99;

        List<Object> mixedList = Arrays.asList(human, student,number, notHuman); // разные объекты добавляем
        int result = ReflectionDemo.countHumans(mixedList);

        assertEquals(2, result); // Только human и student
    }

    @Test
    void testCountHumansWithNull() {
        List<Object> listWithNull = Arrays.asList(new Human("Аксенов", "Вячеслав", "Иванович", 1974), null);
        int result = ReflectionDemo.countHumans(listWithNull);
        assertEquals(1, result); // null не считается Human
    }

    //2 добавить приват метод
    @Test
    public void testGetPublicMethodNames() {
        Object obj = new Object();
        List<String> expectedAnswer = Arrays.asList(
                "wait",
                "wait",
                "wait",
                "equals",
                "toString",
                "hashCode",
                "getClass",
                "notify",
                "notifyAll");
        Collections.sort(expectedAnswer); // Сортируем для сравнения
        List<String> actualResult = ReflectionDemo.getPublicMethodNames(obj);
        Collections.sort(actualResult);   // Так же сортируем фактический результат
        assertEquals(expectedAnswer, actualResult);
    }



    //3
    @Test
    public void testGetSuperClassNames() {
        // Проверка для простого объекта Object
        assertEquals(List.of("java.lang.Object"), ReflectionDemo.getSuperClassNames(new Object()));

        // Проверка для строки String и объекта Object
        assertEquals(List.of("java.lang.String", "java.lang.Object"), ReflectionDemo.getSuperClassNames("AAA"));

        assertEquals(List.of("Magistrant", "Student", "Human","java.lang.Object"), ReflectionDemo.getSuperClassNames(new Magistrant("Oblomov","Miron","",1998,"IMIT")));
    }
}